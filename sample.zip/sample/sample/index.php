<?php
session_start();
//$username = $_SESSION['username'];

require_once('connection.php');


if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    // Redirect the user to the login page
    header('Location: login.php');
    exit;
}
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Scheirman Construction Consolidated Inc</title>
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="icon" type="image/png" href="img/lg.png">
  <link rel="stylesheet" href="css/custom.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <style>
    table {
      border-collapse: collapse;
      width: 100%;
    }
    th, td {
      text-align: left;
      padding: 8px;
    }
    tr:nth-child(even) {
      background-color: #f2f2f2;
    }
    th {
      background-color: #4CAF50;
      color: white;
    }

    body {
      font-family: 'Poppins', Arial, sans-serif;
      background-image: url("images/blurr.png");
      background-size: cover;
    }

    .container {
      padding: 20px;
    }

    .main-content {
      background-color: white;
      padding: 20px;
      border-radius: 10px;
    }

    .top-navbar {
      background-color: orange;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 10px;
    }

    .xd-topbar {
		display: flex;
		align-items: center;
		background-image: url('img/viberbuilding.png');
		}

    .xp-menubar {
      cursor: pointer;
    }

    .material-icons {
      font-size: 24px;
    }
    .pagination {
  margin-top: 10px;
  text-align: center;
}

.pagination a {
  display: inline-block;
  padding: 6px 12px;
  margin-right: 5px;
  background-color: #f5f5f5;
  border: 1px solid #ddd;
  color: #337ab7;
  text-decoration: none;
}

.pagination a:hover {
  background-color: #ddd;
}

.pagination .active {
  background-color: #337ab7;
  color: #fff;
  border: 1px solid #337ab7;
}
  </style>
</head>
<body>
  <div class="container">
    <div class="main-content">
      <div class="top-navbar">
        <div class="xd-topbar">
          <div class="col-2 col-md-1 col-lg-1 order-2 order-md-1 align-self-center">
          <div class="xp-menubar">
			<img src="img/viber.png" alt="Image Description" style="max-width: 500%; height: auto;">
			</div>
          </div>
        </div>
      </div>
      <table class="table table-striped table-hover">
        <thead>
          <tr>
            <!-- Table header content here -->
          </tr>
        </thead>
        <tbody>
          <?php 

          // Number of results to display per page
$resultsPerPage = 20;

// Get the current page number from the query string
$page = isset($_GET['page']) ? $_GET['page'] : 1;

// Calculate the offset for the SQL query
$offset = ($page - 1) * $resultsPerPage;

 // Retrieve all IDs from all tables
$tables = array(
  'character_reference',
  'educational_background',
  'e_signature',
  'family_background',
  'licensure',
  'nature_of_application',
  'personal_information',
  'personal_sheet',
  'person_emergency_contact',
  'position_apply',
  'upload',
  'work_experience'
);

$ids = array();
foreach ($tables as $table) {
  if ($table == "personal_information") {
    $field = "id";
  } else {
    $field = "id";
  }
}

// Remove duplicates from the array
$ids = array_unique($ids);

// Execute the query outside the loop
// Modify your SQL query to include the ORDER BY clause
$query = "SELECT personal_information.id, personal_information.given_name, personal_information.surName, 
          position_apply.choice1, position_apply.choice2, work_experience.*, personal_information.submission_datetime
          FROM personal_information
          JOIN position_apply ON personal_information.id = position_apply.id
          JOIN work_experience ON personal_information.id = work_experience.id
          ORDER BY personal_information.id DESC
          LIMIT $offset, $resultsPerPage";

// Execute the modified query
$result = mysqli_query($conn, $query);

// Fetch and display the data in descending order
while ($row = mysqli_fetch_array($result)) {
    // Display the data here
  $id = $row['id'];
  $given_name = $row['given_name'];
  $surName = $row['surName'];
  $choice1 = $row['choice1'];
  $choice2 = $row['choice2'];
  $submission_datetime = date('F d, Y h:i A', strtotime($row['submission_datetime']));

  $data[] = "<tr><td><a href='view_submission_details.php?id=$id'>Name: $given_name $surName - POSITION: $choice1 / $choice2 - SUBMISSION DATE: $submission_datetime</a></td></tr>";
}

// Display the data in the order received from the database (latest submission first)
foreach ($data as $row) {
  echo $row;
}


?>
        </tbody>
      </table>
     <?php
// Calculate the total number of rows in the result set
$totalRows = mysqli_num_rows($result);

// Calculate the total number of pages
$totalPages = ceil($totalRows / $resultsPerPage);

// Ensure that $totalPages is at least 1
$totalPages = max(1, $totalPages);

if ($totalPages > 1) {
    echo "<div class='pagination'>";

    // Previous page link
    if ($page > 1) {
        echo "<a href='index.php?page=" . ($page - 1) . "'>&laquo; Previous</a>";
    }

    // Page links
    for ($i = 1; $i <= $totalPages; $i++) {
        echo "<a href='index.php?page=$i'>$i</a>";
    }

    // Next page link
    if ($page < $totalPages) {
        echo "<a href='index.php?page=" . ($page + 1) . "'>Next &raquo;</a>";
    }

    echo "</div>";
}
      ?>
    </div>
  </div>
  <script src="js/jquery-3.3.1.slim.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery-3.3.1.min.js"></script>
</body>
</html>