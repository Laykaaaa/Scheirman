<?php
session_start();
require_once('connection.php');

// Retrieve the username and password from the URL parameters
$username = $_POST['username'];
$password = $_POST['password'];

// Perform user authentication against the database
$query = "SELECT * FROM user WHERE username='$username' AND Password='$password'";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
    // User is authenticated, set the loggedin session variable
    $_SESSION['loggedin'] = true;

    // Redirect the user to the index.php page or any other authorized page
    header('Location: index.php');
    exit;
} else {
    ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

    // User authentication failed, display an error message
    echo '<script>alert("Invalid username or password");</script>';
    echo '<script>window.location.href = "login.php";</script>';
    exit;
}
?>

<script type="text/javascript">
window.location="";
</script>
