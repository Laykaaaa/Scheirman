<?php
session_start();

require_once('connection.php');

// Check if the form is submitted
if (isset($_POST['submit'])) {
    // Get the entered username and password
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Redirect to check-login.php for user authentication
    header("Location: check-login.php?username=$username&password=$password");
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Scheirman Construction Consolidated Inc.</title>
  <!-- Font Awesome CDN -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  <!-- Login CSS file -->
  <link rel="stylesheet" type="text/css" href="adminloginstyle.css">
  <link rel="icon" type="img/png" href="img/lg.png ">
</head>

<body>
  <div class="container">
  <div style="text-align: center;">
    <img src="images/logo.png" alt="Image Description" style="width: 500px;"><br>
  </div>
    <div class="login-form">
      <h1>Sign In</h1>
      <!-- Goes directly to the login.php -->
      <form action="check-login.php" method="post">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="submit" name="submit" value="Sign In">
      </form>
    </div>
  </div>
</body>

</html>
