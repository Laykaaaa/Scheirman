<?php
//connects to database 
	include ('connection.php');

//code displays error for debugging just uncomment if unnecesary di ko alam spelling
	ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

//something about when user press the submit button it will get the value of the textbox
	if ($_SERVER["REQUEST_METHOD"] == "POST") {

		// Personal sheet
$date_accomplished = isset($_POST['date_accomplished']) ? $_POST['date_accomplished'] : '';
$n_application = isset($_POST['n_application']) ? $_POST['n_application'] : '';

if (isset($_FILES['image'])) {
    $allowTypes = array('jpg', 'png', 'jpeg', 'gif');
    $fileError = $_FILES['image']['error'];

    // Check if a file was uploaded or if the file upload had no errors
    if ($fileError === UPLOAD_ERR_OK || $fileError === UPLOAD_ERR_NO_FILE) {
        $image = addslashes(file_get_contents($_FILES['image']['tmp_name']));
        $image_name = addslashes($_FILES['image']['name']);
        $image_size = getimagesize($_FILES['image']['tmp_name']);

        // Check if the uploaded file is an image
        if ($fileError === UPLOAD_ERR_NO_FILE || $image_size !== false) {
            // Create an SQL statement to insert the data into the table
            $query = "INSERT INTO personal_sheet (date_accomplished, n_application, image) 
                      VALUES ('$date_accomplished', '$n_application', '$image')";

            // Execute the SQL statement and check if it was successful
            if (mysqli_query($conn, $query)) {
                echo "Data saved successfully.";
            } else {
                echo "Error: " . mysqli_error($conn);
            }
        } else {
            echo "File is not an image.";
        }
    } else {
        echo "File upload error: " . $fileError;
    }
}
		
		//nature of application data
		$scci_website = isset($_POST['scci_website']) ? 1 : 0;
		$walk_in = isset($_POST['walk_in']) ? 1 : 0;
		$indeed = isset($_POST['indeed']) ? 1 : 0;
		$jobstreet = isset($_POST['jobstreet']) ? 1 : 0;
		$facebook = isset($_POST['facebook']) ? 1 : 0;
		$referred_by = isset($_POST['referred_by']) ? $_POST['referred_by'] : '';
		
		//possition apply data
		$choice1 = isset($_POST['choice1']) ? $_POST['choice1'] : '';
		$choice2 = isset($_POST['choice2']) ? $_POST['choice2'] : '';

		//personal information
		$surName = isset($_POST['surName']) ? $_POST['surName'] : '';
		$given_name = isset($_POST['given_name']) ? $_POST['given_name'] : '';
		$middle_name = isset($_POST['middle_name']) ? $_POST['middle_name'] : '';
		$middle_initial = isset($_POST['middle_initial']) ? $_POST['middle_initial'] : '';
		$nickName = isset($_POST['nickName']) ? $_POST['nickName'] : '';
		$present_address = isset($_POST['present_address']) ? $_POST['present_address'] : '';
		$Contact_NO = isset($_POST['Contact_NO']) ? $_POST['Contact_NO'] : '';
		$permanent_address = isset($_POST['permanent_address']) ? $_POST['permanent_address'] : '';
		$Contact_NO1 = isset($_POST['Contact_NO1']) ? $_POST['Contact_NO1'] : '';
		$birth_date = isset($_POST['birth_date']) ? $_POST['birth_date'] : '';
		$birth_place = isset($_POST['birth_place']) ? $_POST['birth_place'] : '';
		$civil_status = isset($_POST['civil_status']) ? $_POST['civil_status'] : '';
		$gender = isset($_POST['gender']) ? $_POST['gender'] : '';
		$religion = isset($_POST['religion']) ? $_POST['religion'] : '';
		$sss_NO = isset($_POST['sss_NO']) ? $_POST['sss_NO'] : '';
		$pag_ibig_NO = isset($_POST['pag_ibig_NO']) ? $_POST['pag_ibig_NO'] : '';
		$philhealth_NO = isset($_POST['philhealth_NO']) ? $_POST['philhealth_NO'] : '';
		$tin = isset($_POST['tin']) ? $_POST['tin'] : '';
		$tax_Status = isset($_POST['tax_Status']) ? $_POST['tax_Status'] : '';

		// family/relatives information data
		$tax_Status = isset($_POST['tax_Status']) ? $_POST['tax_Status'] : '';
		$fam_name = isset($_POST['fam_name']) ? $_POST['fam_name'] : '';
		$fam_relationship = isset($_POST['fam_relationship']) ? $_POST['fam_relationship'] : '';
		$fam_age = isset($_POST['fam_age']) ? $_POST['fam_age'] : '';
		$fam_birth_date = isset($_POST['fam_birth_date']) ? $_POST['fam_birth_date'] : '';
		$fam_civil_status = isset($_POST['fam_civil_status']) ? $_POST['fam_civil_status'] : '';
		$fam_occupation = isset($_POST['fam_occupation']) ? $_POST['fam_occupation'] : '';
		$fam_employer_school = isset($_POST['fam_employer_school']) ? $_POST['fam_employer_school'] : '';
		
		//family data
		$fam_name1 = isset($_POST['fam_name1']) ? $_POST['fam_name1'] : '';
		$fam_relationship1 = isset($_POST['fam_relationship1']) ? $_POST['fam_relationship1'] : '';
		$fam_age1 = isset($_POST['fam_age1']) ? $_POST['fam_age1'] : '';
		$fam_birth_date1 = isset($_POST['fam_birth_date1']) ? $_POST['fam_birth_date1'] : '';
		$fam_civil_status1 = isset($_POST['fam_civil_status1']) ? $_POST['fam_civil_status1'] : '';
		$fam_occupation1 = isset($_POST['fam_occupation1']) ? $_POST['fam_occupation1'] : '';
		$fam_employer_school1 = isset($_POST['fam_employer_school1']) ? $_POST['fam_employer_school1'] : '';

		$fam_name2 = isset($_POST['fam_name2']) ? $_POST['fam_name2'] : '';
		$fam_relationship2 = isset($_POST['fam_relationship2']) ? $_POST['fam_relationship2'] : '';
		$fam_age2 = isset($_POST['fam_age2']) ? $_POST['fam_age2'] : '';
		$fam_birth_date2 = isset($_POST['fam_birth_date2']) ? $_POST['fam_birth_date2'] : '';
		$fam_civil_status2 = isset($_POST['fam_civil_status2']) ? $_POST['fam_civil_status2'] : '';
		$fam_occupation2 = isset($_POST['fam_occupation2']) ? $_POST['fam_occupation2'] : '';
		$fam_employer_school2 = isset($_POST['fam_employer_school2']) ? $_POST['fam_employer_school2'] : '';

		$fam_name3 = isset($_POST['fam_name3']) ? $_POST['fam_name3'] : '';
		$fam_relationship3 = isset($_POST['fam_relationship3']) ? $_POST['fam_relationship3'] : '';
		$fam_age3 = isset($_POST['fam_age3']) ? $_POST['fam_age3'] : '';
		$fam_birth_date3 = isset($_POST['fam_birth_date3']) ? $_POST['fam_birth_date3'] : '';
		$fam_civil_status3 = isset($_POST['fam_civil_status3']) ? $_POST['fam_civil_status3'] : '';
		$fam_occupation3 = isset($_POST['fam_occupation3']) ? $_POST['fam_occupation3'] : '';
		$fam_employer_school3 = isset($_POST['fam_employer_school3']) ? $_POST['fam_employer_school3'] : '';

		$fam_name4 = isset($_POST['fam_name4']) ? $_POST['fam_name4'] : '';
		$fam_relationship4 = isset($_POST['fam_relationship4']) ? $_POST['fam_relationship4'] : '';
		$fam_age4 = isset($_POST['fam_age4']) ? $_POST['fam_age4'] : '';
		$fam_birth_date4 = isset($_POST['fam_birth_date4']) ? $_POST['fam_birth_date4'] : '';
		$fam_civil_status4 = isset($_POST['fam_civil_status4']) ? $_POST['fam_civil_status4'] : '';
		$fam_occupation4 = isset($_POST['fam_occupation4']) ? $_POST['fam_occupation4'] : '';
		$fam_employer_school4 = isset($_POST['fam_employer_school4']) ? $_POST['fam_employer_school4'] : '';

		$fam_name5 = isset($_POST['fam_name5']) ? $_POST['fam_name5'] : '';
		$fam_relationship5 = isset($_POST['fam_relationship5']) ? $_POST['fam_relationship5'] : '';
		$fam_age5 = isset($_POST['fam_age5']) ? $_POST['fam_age5'] : '';
		$fam_birth_date5 = isset($_POST['fam_birth_date5']) ? $_POST['fam_birth_date5'] : '';
		$fam_civil_status5 = isset($_POST['fam_civil_status5']) ? $_POST['fam_civil_status5'] : '';
		$fam_occupation5 = isset($_POST['fam_occupation5']) ? $_POST['fam_occupation5'] : '';
		$fam_employer_school5 = isset($_POST['fam_employer_school5']) ? $_POST['fam_employer_school5'] : '';
		
		//education data 
		$post_graduate_from = isset($_POST['post_graduate_from']) ? $_POST['post_graduate_from'] : '';
		$post_graduate_to = isset($_POST['post_graduate_to']) ? $_POST['post_graduate_to'] : '';
		$post_graduate_course = isset($_POST['post_graduate_course']) ? $_POST['post_graduate_course'] : '';
		$post_graduate_school = isset($_POST['post_graduate_school']) ? $_POST['post_graduate_school'] : '';

		$tertiary_from = isset($_POST['tertiary_from']) ? $_POST['tertiary_from'] : '';
		$tertiary_to = isset($_POST['tertiary_to']) ? $_POST['tertiary_to'] : '';
		$tertiary_course = isset($_POST['tertiary_course']) ? $_POST['tertiary_course'] : '';
		$tertiary_school = isset($_POST['tertiary_school']) ? $_POST['tertiary_school'] : '';

		$vocational_from = isset($_POST['vocational_from']) ? $_POST['vocational_from'] : '';
		$vocational_to = isset($_POST['vocational_to']) ? $_POST['vocational_to'] : '';
		$vocational_course = isset($_POST['vocational_course']) ? $_POST['vocational_course'] : '';
		$vocational_school = isset($_POST['vocational_school']) ? $_POST['vocational_school'] : '';

		$high_school_from = isset($_POST['high_school_from']) ? $_POST['high_school_from'] : '';
		$high_school_to = isset($_POST['high_school_to']) ? $_POST['high_school_to'] : '';
		$high_school_course = isset($_POST['high_school_course']) ? $_POST['high_school_course'] : '';
		$high_school_school = isset($_POST['high_school_school']) ? $_POST['high_school_school'] : '';

		// Work experience data
		$work_company_name = isset($_POST['work_company_name']) ? $_POST['work_company_name'] : '';
		$work_contact_NO = isset($_POST['work_contact_NO']) ? $_POST['work_contact_NO'] : '';
		$work_complete_address = isset($_POST['work_complete_address']) ? $_POST['work_complete_address'] : '';
		$work_employment_from = isset($_POST['work_employment_from']) ? $_POST['work_employment_from'] : '';
		$work_employment_to = isset($_POST['work_employment_to']) ? $_POST['work_employment_to'] : '';
		$work_lastJob_title = isset($_POST['work_lastJob_title']) ? $_POST['work_lastJob_title'] : '';
		$work_Superiors_name = isset($_POST['work_Superiors_name']) ? $_POST['work_Superiors_name'] : '';
		$work_salary = isset($_POST['work_salary']) ? $_POST['work_salary'] : '';
		$work_salary1 = isset($_POST['work_salary1']) ? $_POST['work_salary1'] : '';
		$work_Reason_for_leaving = isset($_POST['work_Reason_for_leaving']) ? $_POST['work_Reason_for_leaving'] : '';
		$work_list_duties_promotion = isset($_POST['work_list_duties_promotion']) ? $_POST['work_list_duties_promotion'] : '';

		$work_company_name1 = isset($_POST['work_company_name1']) ? $_POST['work_company_name1'] : '';
		$work_contact_NO1 = isset($_POST['work_contact_NO1']) ? $_POST['work_contact_NO1'] : '';
		$work_complete_address1 = isset($_POST['work_complete_address1']) ? $_POST['work_complete_address1'] : '';
		$work_employment_from1 = isset($_POST['work_employment_from1']) ? $_POST['work_employment_from1'] : '';
		$work_employment_to1 = isset($_POST['work_employment_to1']) ? $_POST['work_employment_to1'] : '';
		$work_lastJob_title1 = isset($_POST['work_lastJob_title1']) ? $_POST['work_lastJob_title1'] : '';
		$work_Superiors_name1 = isset($_POST['work_Superiors_name1']) ? $_POST['work_Superiors_name1'] : '';
		$work_salary2 = isset($_POST['work_salary2']) ? $_POST['work_salary2'] : '';
		$work_salary3 = isset($_POST['work_salary3']) ? $_POST['work_salary3'] : '';
		$work_Reason_for_leaving1 = isset($_POST['work_Reason_for_leaving1']) ? $_POST['work_Reason_for_leaving1'] : '';
		$work_list_duties_promotion1 = isset($_POST['work_list_duties_promotion1']) ? $_POST['work_list_duties_promotion1'] : '';


		// Licensure
// Retrieve the values from the form
$board_exam_type = isset($_POST['board_exam_type']) ? $_POST['board_exam_type'] : '';
$date_of_exam = isset($_POST['date_of_exam']) ? $_POST['date_of_exam'] : '';
$rating = isset($_POST['rating']) ? $_POST['rating'] : '';

if (isset($_FILES['license_NO'])) {
    $allowTypes = array('jpg', 'png', 'jpeg', 'gif');
    $fileError = $_FILES['license_NO']['error'];

    // Check if a file was uploaded or if the file upload had no errors
    if ($fileError === UPLOAD_ERR_OK || $fileError === UPLOAD_ERR_NO_FILE) {
        $image = addslashes(file_get_contents($_FILES['license_NO']['tmp_name']));
        $image_name = addslashes($_FILES['license_NO']['name']);
        $image_size = getimagesize($_FILES['license_NO']['tmp_name']);

        // Check if the uploaded file is an image
        if ($fileError === UPLOAD_ERR_NO_FILE || $image_size !== false) {
            // Create an SQL statement to insert the data into the table
            $query = "INSERT INTO licensure (board_exam_type, date_of_exam, rating, license_NO) 
                      VALUES ('$board_exam_type', '$date_of_exam', '$rating', '$image')";

            // Execute the SQL statement and check if it was successful
            if (mysqli_query($conn, $query)) {
                echo "Data saved successfully.";
            } else {
                echo "Error: " . mysqli_error($conn);
            }
        } else {
            echo "File is not an image.";
        }
    } else {
        echo "File upload error: " . $fileError;
    }
}

		//checkbox
		$crime = isset($_POST['crime']) ? $_POST['crime'] : '';
		$crime_text = isset($_POST['crime_text']) ? $_POST['crime_text'] : '';
		$hospitalized = isset($_POST['hospitalized']) ? $_POST['hospitalized'] : '';
		$hospitalized_text = isset($_POST['hospitalized_text']) ? $_POST['hospitalized_text'] : '';
		$health_condition= isset($_POST['health_condition']) ? $_POST['health_condition'] : '';
		$health_condition_text = isset($_POST['health_condition_text']) ? $_POST['health_condition_text'] : '';

		//character reference
		$Name_reference = isset($_POST['Name_reference']) ? $_POST['Name_reference'] : '';
		$contact_NO_reference = isset($_POST['contact_NO_reference']) ? $_POST['contact_NO_reference'] : '';
		$reference_company = isset($_POST['reference_company']) ? $_POST['reference_company'] : '';
		$reference_position = isset($_POST['reference_position']) ? $_POST['reference_position'] : '';
		$reference_relationship = isset($_POST['reference_relationship']) ? $_POST['reference_relationship'] : '';
		$Name_reference1 = isset($_POST['Name_reference1']) ? $_POST['Name_reference1'] : '';
		$contact_NO_reference1 = isset($_POST['contact_NO_reference1']) ? $_POST['contact_NO_reference1'] : '';
		$reference_company1 = isset($_POST['reference_company1']) ? $_POST['reference_company1'] : '';
		$reference_position1 = isset($_POST['reference_position1']) ? $_POST['reference_position1'] : '';
		$reference_relationship1 = isset($_POST['reference_relationship1']) ? $_POST['reference_relationship1'] : '';

		//person_emergency_contact
		$Name_emergency = isset($_POST['Name_emergency']) ? $_POST['Name_emergency'] : '';
		$contact_NO_emergency = isset($_POST['contact_NO_emergency']) ? $_POST['contact_NO_emergency'] : '';
		$address_emergency = isset($_POST['address_emergency']) ? $_POST['address_emergency'] : '';
		$relationship_emergency = isset($_POST['relationship_emergency']) ? $_POST['relationship_emergency'] : '';

	// e signature
$e_signature_name = isset($_POST['e_signature_name']) ? $_POST['e_signature_name'] : '';
$name_esignature = isset($_POST['name_esignature']) ? $_POST['name_esignature'] : '';

if (isset($_FILES['esig_name'])) {
    $allowTypes = array('jpg', 'png', 'jpeg', 'gif');
    $fileError = $_FILES['esig_name']['error'];

    // Check if a file was uploaded or if the file upload had no errors
    if ($fileError === UPLOAD_ERR_OK || $fileError === UPLOAD_ERR_NO_FILE) {
        $image = addslashes(file_get_contents($_FILES['esig_name']['tmp_name']));
        $image_name = addslashes($_FILES['esig_name']['name']);
        $image_size = getimagesize($_FILES['esig_name']['tmp_name']);

        // Check if the uploaded file is an image
        if ($fileError === UPLOAD_ERR_NO_FILE || $image_size !== false) {
            $sql = "INSERT INTO e_signature (esig_name, name_esignature, e_signature_name) 
                    VALUES ('$image', '$name_esignature', '$e_signature_name')";
            mysqli_query($conn, $sql);
            echo "Data saved successfully.";
        } else {
            echo "File is not an image.";
        }
    } else {
        echo "File upload error: " . $fileError;
    }
}
        
		// nature of application data	
        //inserts the data to the database 
		$sql1 = "INSERT INTO nature_of_application (scci_website, walk_in, indeed, jobstreet, facebook, referred_by)
		VALUES ('$scci_website', '$walk_in', '$indeed', '$jobstreet', '$facebook', '$referred_by')";


	   	$sql2 = "INSERT INTO position_apply (choice1, choice2) 
		VALUES ('$choice1', '$choice2')";


	  	 $sql3 = "INSERT INTO personal_information (surName, given_name,middle_name, middle_initial, nickName, present_address, Contact_NO, permanent_address, Contact_NO1, birth_date, birth_place, civil_status, gender, religion, sss_NO, pag_ibig_NO, philhealth_NO, tin, tax_Status)
		VALUES ('$surName', '$given_name', '$middle_name','$middle_initial', '$nickName', '$present_address', '$Contact_NO', '$permanent_address', '$Contact_NO1', '$birth_date', '$birth_place', '$civil_status', '$gender', '$religion', '$sss_NO', '$pag_ibig_NO', '$philhealth_NO', '$tin', '$tax_Status')";


	  	 $sql4 = "INSERT INTO family_background (fam_name, fam_relationship, fam_age, fam_birth_date, fam_civil_status, fam_occupation, fam_employer_school, fam_name1, fam_relationship1, fam_age1, fam_birth_date1, fam_civil_status1, fam_occupation1, fam_employer_school1, fam_name2, fam_relationship2, fam_age2, fam_birth_date2, fam_civil_status2, fam_occupation2, fam_employer_school2, fam_name3, fam_relationship3, fam_age3, fam_birth_date3, fam_civil_status3, fam_occupation3, fam_employer_school3, fam_name4, fam_relationship4, fam_age4, fam_birth_date4, fam_civil_status4, fam_occupation4, fam_employer_school4, fam_name5, fam_relationship5, fam_age5, fam_birth_date5, fam_civil_status5, fam_occupation5, fam_employer_school5)
	  	 VALUES ('$fam_name', '$fam_relationship', '$fam_age', '$fam_birth_date', '$fam_civil_status', '$fam_occupation', '$fam_employer_school', '$fam_name1', '$fam_relationship1', '$fam_age1', '$fam_birth_date1', '$fam_civil_status1', '$fam_occupation1', '$fam_employer_school1', '$fam_name2', '$fam_relationship2', '$fam_age2', '$fam_birth_date2', '$fam_civil_status2', '$fam_occupation2', '$fam_employer_school2', '$fam_name3', '$fam_relationship3', '$fam_age3', '$fam_birth_date3', '$fam_civil_status3', '$fam_occupation3', '$fam_employer_school3', '$fam_name4', '$fam_relationship4', '$fam_age4', '$fam_birth_date4', '$fam_civil_status4', '$fam_occupation4', '$fam_employer_school4', '$fam_name5', '$fam_relationship5', '$fam_age5', '$fam_birth_date5', '$fam_civil_status5', '$fam_occupation5', '$fam_employer_school5')";

		// Removing empty values
		$sql4 = str_replace(", ,", ",", $sql4);
		$sql4 = str_replace(",,", ",", $sql4);
		$sql4 = str_replace(", )", ")", $sql4);

		$sql5 = "INSERT INTO educational_background (post_graduate_from, post_graduate_to, post_graduate_course, post_graduate_school, tertiary_from, tertiary_to, tertiary_course, tertiary_school, vocational_from, vocational_to, vocational_course, vocational_school, high_school_from, high_school_to, high_school_course, high_school_school)
		VALUES ('$post_graduate_from', '$post_graduate_to', '$post_graduate_course', '$post_graduate_school', '$tertiary_from', '$tertiary_to', '$tertiary_course', '$tertiary_school', '$vocational_from', '$vocational_to', '$vocational_course', '$vocational_school', '$high_school_from', '$high_school_to', '$high_school_course', '$high_school_school')";


		$sql6 = "INSERT INTO work_experience (work_company_name, work_contact_NO ,work_complete_address, work_employment_from, work_employment_to, work_lastJob_title, work_Superiors_name, work_salary, work_salary1, work_Reason_for_leaving, work_list_duties_promotion ,work_company_name1, work_contact_NO1, work_complete_address1, work_employment_from1, work_employment_to1, work_lastJob_title1, work_Superiors_name1, work_salary2, work_salary3, work_Reason_for_leaving1, work_list_duties_promotion1)
        VALUES ('$work_company_name','$work_contact_NO','$work_complete_address','$work_employment_from','$work_employment_to','$work_lastJob_title','$work_Superiors_name','$work_salary','$work_salary1','$work_Reason_for_leaving','$work_list_duties_promotion','$work_company_name1','$work_contact_NO1','$work_complete_address1','$work_employment_from1','$work_employment_to1','$work_lastJob_title1','$work_Superiors_name1','$work_salary2','$work_salary3','$work_Reason_for_leaving1','$work_list_duties_promotion1')";

		$sql7 = "INSERT INTO checkbox (crime, crime_text,hospitalized,hospitalized_text,health_condition,health_condition_text) 
		VALUES ('$crime', '$crime_text' , '$hospitalized' , '$hospitalized_text' , '$health_condition' , '$health_condition_text')";


		$sql8 = "INSERT INTO character_reference (Name_reference, contact_NO_reference,reference_company,reference_position,reference_relationship, Name_reference1, contact_NO_reference1, reference_company1, reference_position1, reference_relationship1 ) 
		VALUES ('$Name_reference', '$contact_NO_reference', '$reference_company' , '$reference_position' , '$reference_relationship'
		,'$Name_reference1' , '$contact_NO_reference1' , '$reference_company1' , '$reference_position1' , '$reference_relationship1')";


		$sql9 = "INSERT INTO person_emergency_contact (Name_emergency, contact_NO_emergency,address_emergency, relationship_emergency) 
		VALUES ('$Name_emergency', '$contact_NO_emergency' , '$address_emergency' , '$relationship_emergency')";
		
	   // Execute the queries
	   if (mysqli_query($conn, $sql1) && mysqli_query($conn, $sql2) && mysqli_query($conn, $sql3) && mysqli_query($conn, $sql4) && mysqli_query($conn, $sql5) && mysqli_query($conn, $sql6) && mysqli_query($conn,$sql7) && mysqli_query($conn,$sql8) && mysqli_query($conn,$sql9)) {
		  
		   echo "New record saved successfully";
		   header('Location: redirect.php');
		} else {
		  echo "Error: " .  "<br>" . $conn->error;
		}
		$conn->close();
	  }
	  ?>

<!DOCTYPE html>
<html>
<head>
	<title>Personal Information Sheet</title>
    <link rel="icon" type="image/png" href="img/lg.png">
	<link rel="stylesheet" type="text/css" href="forms.css">
</head>
<body>	


<!-- SCHEIRMAN'S LOGO  -->

<div style="text-align: center;">
  <img src="images/logo.png" alt="Image Description" style="width: 500px;"><br>
</div>

            <!--code na kukunin lahat ng naenter ng user  -->
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data" >
                <h1>PERSONAL INFORMATION SHEET</h1>
            <p>Date Accomplished: <input type="date" name="date_accomplished"></p>
            <p>Nature of Application: <input type="text" name="n_application" style="border: none;" placeholder="Nature of Application"></p>
            <p>
			<label><input type="checkbox" name="scci_website" value="SCCI WEBSITE">Website</label>
			<label><input type="checkbox" name="walk_in" value="Walk-In"> Walk-In</label>
			<label><input type="checkbox" name="indeed" value="Indeed"> Indeed</label>
			<label><input type="checkbox" name="jobstreet" value="Jobstreet"> Jobstreet</label>
			<label style="position: relative;">
			<input type="checkbox" name="facebook" value="Facebook">Facebook
			<div class="picture-container" style="width: 100px; height: 100px; margin-top: 150px; margin-left: 20px;">
  				<img id="id-picture" src="https://www.w3schools.com/w3images/avatar2.png" alt="ID Picture" width="100" height="100">
 			<div class="upload-container" style="margin-top: 10px; margin-left: -50px;">
   			<label for="image" style="margin-top: 2px; margin-left: 50px;">Upload picture:</label>
   			<input type="file" name="image" onchange="showImage(event)" style="margin-left: 10px;" >
  		</div>
	</div>
</label>
		</p>
		<p>
			<label><input type="checkbox" name="referred_by" value="Referred by:">Referred By:</label>
			<input type="text" name="referred_by" style="border: none;" placeholder="Referred By:">
		</p>
		<p>
			<label>Position Applying For:</label><br>
			<span style="text-decoration: underline;">1st Choice:</span> <input type="text" name="choice1" style="border: none;" placeholder="Enter 1st choice here">
			<span style="text-decoration: underline;">2nd Choice:</span> <input type="text" name="choice2" style="border: none;" placeholder="Enter 2nd choice here">
		</p>

            <!-- FUNCTION FOR IMAGE UPLOAD -->
            <script>
            function showImage(event) {
                var input = event.target;
                if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    document.getElementById('id-picture').src = e.target.result;
                };
                reader.readAsDataURL(input.files[0]);
                }
            }
            </script>


			<!-- TABLE FOR PERSONAL INFORMATION -->
			<h2>Personal Information</h2>
			<table class="my-table">
				<!-- NAME -->	
				<thead>
					<tr>
						<th class="surName" style="background-color: #FFC000;">Surname</th>
						<th class="given_name" style="background-color: #FFC000;">Given Name</th>
						<th class="middle_name" style="background-color: #FFC000;">Middle Name</th>
						<th class="middle_initial" style="background-color: #FFC000;">Middle Initial</th>
						<th class="nickName" style="background-color: #FFC000;">Nickname</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><input type="text" name="surName" placeholder="Surname" required></td>
						<td><input type="text" name="given_name" placeholder="Given Name"></td>
						<td><input type="text" name="middle_name" placeholder="Middle-name"></td>
						<td><input type="text" name="middle_initial" placeholder="Middle-initial"></td>
						<td><input type="text" name="nickName" placeholder="Nickname"></td>
					</tr>
				</tbody>

				  <!-- ADDRESS -->
				  <tr>
					<th class="present_address" style="background-color: #FFC000;">Address:</th>
						<td colspan="2">
							<label for="present-address" >Present Address: </label>
							<input type="text" name="present_address" placeholder="Present Address">
						</td>   
						<td colspan="2">
							<label for="Contact_NO">Contact Number: </label>
							<input type="tel" name="Contact_NO" pattern="[0-9]*" maxlength="11" placeholder="Contact Number">
						</td>
				  </tr>							  
				  <tr>
					<th class="permanent_address-address" style="background-color: #FFC000;">Address:</th>
						<td colspan="2">
							<label for="permanent-address">Permanent Address: </label>
							<input type="text" name="permanent_address" placeholder="Permanent Address">
						</td>
						<td colspan="2">
							<label for="Contact_NO1">Contact Number: </label>
							<input type="tel" name="Contact_NO1" pattern="[0-9]*" maxlength="11" placeholder="Contact Number">
						</td>
				  </tr>
				
				  <!-- OTHER INFORMATION -->
				  <thead>
					<tr>
					  <th class="birth_date" style="background-color: #FFC000;">Birthdate</th>
					  <th class="birth_place" style="background-color: #FFC000;">Birthplace</th>
					  <th class="civil_status" style="background-color: #FFC000;">Civil Status</th>
					  <th class="gender" style="background-color: #FFC000;">Gender</th>
					  <th class="religion" style="background-color: #FFC000;">Religion</th>
					</tr>
				  </thead>	
					<tr>
						<td><input type="date" name="birth_date" id="birth_date"></td>
						<td><input type="text" name="birth_place" id="birth_place"></td>
						<td><input type="text" name="civil_status" id="civil_status"></td>
						<td style="text-align: center;">
                            <select name="gender">
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                                <option value="prefer_not_to_say">Prefer not to say</option>
                            </select>
                        </td>
						<td><input type="text" name="religion" id="religion"></td>
					</tr>
				
				  <!-- ID's -->
				  <thead>
					<tr>
					  <th class="sss" style="background-color: #FFC000;">SSS No.:</th>
					  <th class="pagibig" style="background-color: #FFC000;">PAG-IBIG No.:</th>
					  <th class="philhealth" style="background-color: #FFC000;">Philhealth No.:</th>
					  <th class="tin" style="background-color: #FFC000;">TIN:</th>
					  <th class="tax-status" style="background-color: #FFC000;">Tax Status:</th>
					</tr>
				  </thead>	
				  <tr>
					<td><input type="text" name="sss_NO" pattern="[0-9]*" maxlength="11"></td>
					<td><input type="text" name="pag_ibig_NO" pattern="[0-9]*" maxlength="11" ></td>
					<td><input type="text" name="philhealth_NO" pattern="[0-9]*" maxlength="11"></td>
					<td><input type="text" name="tin" pattern="[0-9]*" maxlength="11"></td>
					<td><input type="text" name="tax_Status" pattern="[0-9]*" maxlength="11"></td>
					</tr>
			</table><br>

				<!-- FAMILY BACKGROUND -->
				<table style="border-collapse: collapse; border: 2px solid black;">
					<caption style="font-size: 1.2em;"><strong>FAMILY BACKGROUND (For Single Employees: Parents, Siblings, Children; For Married Employees: Spouse, Children)</strong></caption>
					<thead>
						<table class="my-table">
							<thead>
								<tr>
								  <th class="age-column" style="background-color: #FFC000;">Name</th>
								  <th class="relationship" style="background-color: #FFC000;">Relationship:</th>
								  <th class="age-column" style="background-color: #FFC000;">Age</th>
								  <th class="birthdate" style="background-color: #FFC000;">Birthdate</th>
								  <th class="civil-status" style="background-color: #FFC000;">Civil Status</th>
								  <th style="background-color: #FFC000;">Occupation</th>
								  <th style="background-color: #FFC000;">Employer/School</th>
								</tr>
							  </thead>	
							<tbody>
							<tr>
							<td><input type="text" name="fam_name" class="transparent-input" required></td>
								<td class="relationship"><input type="text" name="fam_relationship" class="transparent-input"></td>
								<td class="age-column"><input type="text" name="fam_age" maxlength="2" class="transparent-input"></td>
								<td class="birthdate"><input type="date" name="fam_birth_date" id="birthdate"></td>
								<td class="civil-status"><input type="text" name="fam_civil_status" class="transparent-input"></td>
								<td><input type="text" name="fam_occupation" class="transparent-input"></td>
								<td><input type="text" name="fam_employer_school" class="transparent-input"></td>
							</tr>
							<tr>
							    <td><input type="text" name="fam_name1" class="transparent-input"></td>
								<td class="relationship"><input type="text" name="fam_relationship1" class="transparent-input"></td>
								<td class="age-column"><input type="text" name="fam_age1"maxlength="2" class="transparent-input"></td>
								<td class="birthdate"><input type="date" name="fam_birth_date1" id="birthdate"></td>
								<td class="civil-status"><input type="text" name="fam_civil_status1" class="transparent-input"></td>
								<td><input type="text" name="fam_occupation1" class="transparent-input"></td>
								<td><input type="text" name="fam_employer_school1" class="transparent-input"></td>
							</tr>
							<tr>
							<td><input type="text" name="fam_name2" class="transparent-input"></td>
								<td class="relationship"><input type="text" name="fam_relationship2" class="transparent-input"></td>
								<td class="age-column"><input type="text" name="fam_age2" maxlength="2" class="transparent-input"></td>
								<td class="birthdate"><input type="date" name="fam_birth_date2" id="birthdate"></td>
								<td class="civil-status"><input type="text" name="fam_civil_status2" class="transparent-input"></td>
								<td><input type="text" name="fam_occupation2" class="transparent-input"></td>
								<td><input type="text" name="fam_employer_school2" class="transparent-input"></td>
							</tr>
							<tr>
							<td><input type="text" name="fam_name3" class="transparent-input"></td>
								<td class="relationship"><input type="text" name="fam_relationship3" class="transparent-input"></td>
								<td class="age-column"><input type="text" name="fam_age3" maxlength="2" class="transparent-input"></td>
								<td class="birthdate"><input type="date" name="fam_birth_date3" id="birthdate"></td>
								<td class="civil-status"><input type="text" name="fam_civil_status3" class="transparent-input"></td>
								<td><input type="text" name="fam_occupation3" class="transparent-input"></td>
								<td><input type="text" name="fam_employer_school3" class="transparent-input"></td>
							</tr>
							<tr>
							<td><input type="text" name="fam_name4" class="transparent-input"></td>
								<td class="relationship"><input type="text" name="fam_relationship4" class="transparent-input"></td>
								<td class="age-column"><input type="text" name="fam_age4" maxlength="2" class="transparent-input"></td>
								<td class="birthdate"><input type="date" name="fam_birth_date4" id="birthdate"></td>
								<td class="civil-status"><input type="text" name="fam_civil_status4" class="transparent-input"></td>
								<td><input type="text" name="fam_occupation4" class="transparent-input"></td>
								<td><input type="text" name="fam_employer_school4" class="transparent-input"></td>
							</tr>
							</tbody>
						</table>
						<br><br>
			
				<!-- EDUCATIONAL BACKGROUND -->
				<table class="my-table" style="border-collapse: collapse; border: 2px solid black;">
					<caption style="font-size: 1.2em;"><strong>Educational Background</strong></caption>
					<thead>
						<tr>
							<th colspan="2" style="border: 2px solid black; padding: 8px; background-color: #FFC000;"></th>
							<th style="border: 2px solid black; padding: 8px; background-color: #FFC000;">From</th>
							<th style="border: 2px solid black; padding: 8px; background-color: #FFC000;">To</th>
							<th style="border: 2px solid black; padding: 8px; background-color: #FFC000;">Course/Degree</th>
							<th style="border: 2px solid black; padding: 8px; background-color: #FFC000;">School Address</th>
						</tr>
					</thead>
					<tbody>
					<tr>
						<td colspan="2" style="border: 2px solid black; padding: 8px;">Post Graduate</td>
						<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" name="post_graduate_from"></td>
						<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" name="post_graduate_to"></td>
						<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" name="post_graduate_course"></td>
						<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" style="width: 300px;" name="post_graduate_school"></td>
					</tr> 
					<tr>
						<td colspan="2" style="border: 2px solid black; padding: 8px;">Tertiary</td>
						<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" name="tertiary_from"></td>
						<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" name="tertiary_to"></td>
						<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" name="tertiary_course"></td>
						<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" style="width: 300px;" name="tertiary_school"></td>
					</tr>
					<tr>
						<td colspan="2" style="border: 2px solid black; padding: 8px;">Vocational</td>
						<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" name="vocational_from"></td>
						<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" name="vocational_to"></td>
						<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" name="vocational_course"></td>
						<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" style="width: 300px;" name="vocational_school"></td>
					</tr>
					<tr>
					<td colspan="2" style="border: 2px solid black; padding: 8px;">High School</td>
					<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" name="high_school_from"></td>
					<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" name="high_school_to"></td>
					<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" name="high_school_course"></td>
					<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" style="width: 300px;" name="high_school_school"></td>
					</tr>
				</tbody>
				</table>
                <br><br>

                <!-- WORK EXPERIENCE -->
                <table class="my-table">
                	<thead>
                    <caption style="font-size: 1.2em;"><strong>Work Experience (Please list your work experiences beginning with your most recent job.)</strong></caption>
					<tr>
						<th>Company Name</th>
						<th>Contact No.</th>
						<th>Complete Address</th>
						<th>Employment Date</th>						
					</tr>
				    </thead>
                <tbody>
                    <!-- Content Inside Table -->
                    <tr>
                        <td><input type="text" name="work_company_name" class="transparent-input"></td>
                        <td><input type="text" name="work_contact_NO" pattern="[0-9]*" maxlength="11" class="transparent-input"></td>
                        <td><textarea id="reason-for-leaving" name="work_complete_address" rows="4" cols="50" style="resize: none; margin: 0 auto; display: block;"></textarea></td>
                        <td>
                            <div style="text-align: center; font-weight: bold;">FROM:</div>
                            <input type="date" name="work_employment_from" placeholder="From" style="width: 50%; padding: 3px; margin: 0 auto; display: block;">
                            <div style="text-align: center; font-weight: bold; margin-top: 5px;">TO:</div>
                            <input type="date" name="work_employment_to" placeholder="To" style="width: 50%; padding: 3px; margin: 0 auto; display: block;">
                        </td>
                    </tr>
                 <thead>
					<tr>
						<th>List Job Title/Effective Date:</th>
						<th>Superior's Name</th>
						<th>Salary</th>
						<th>Reason For Leaving</th>						
					</tr>
				    </thead>  
                    <!-- 2nd Row Content Inside Table -->
                     <tr>
                        <td><input type="text" name="work_lastJob_title" class="transparent-input"></td>
                        <td><input type="text" name="work_Superiors_name" class="transparent-input"></td>
                       <td>
                         <div style="text-align: center; font-weight: bold;">FROM:</div>
				            <input type="text" name="work_salary" placeholder="From" pattern="[0-9]*" maxlength="11" style="width: 50%; padding: 3px; margin: 0 auto; display: block;">
                             <div style="text-align: center; font-weight: bold; margin-top: 5px;">TO:</div>
				            <input type="text" name="work_salary1" placeholder="to" pattern="[0-9]*" maxlength="11" style="width: 50%; padding: 3px; margin: 0 auto; display: block;">

                        <td><textarea id="reason-for-leaving" name="work_Reason_for_leaving" rows="4"></textarea></td>
                    </tr>
                </tbody>                       
                </table><br><br>
                
                <!-- WORK EXPERIENCE 2 -->
                <table class="my-table">
                	<thead>
					<tr>
						<th>Company Name</th>
						<th>Contact No.</th>
						<th>Complete Address</th>
						<th>Employment Date</th>						
					</tr>
				    </thead>
                <tbody>
                    <!-- Content Inside Table -->
                    <tr>
                        <td><input type="text" name="work_company_name1" class="transparent-input"></td>
                        <td><input type="text" name="work_contact_NO1" pattern="[0-9]*" maxlength="11" class="transparent-input"></td>
                        <td><textarea id="reason-for-leaving" name="work_complete_address1" rows="4" cols="50" style="resize: none; margin: 0 auto; display: block;"></textarea></td>
                        <td>
                            <div style="text-align: center; font-weight: bold;">FROM:</div>
                            <input type="date" name="work_employment_from1" placeholder="From" style="width: 50%; padding: 3px; margin: 0 auto; display: block;">
                            <div style="text-align: center; font-weight: bold; margin-top: 5px;">TO:</div>
                            <input type="date" name="work_employment_to1" placeholder="To" style="width: 50%; padding: 3px; margin: 0 auto; display: block;">
                        </td>
                    </tr>
                 <thead>
					<tr>
						<th>List Job Title/Effective Date:</th>
						<th>Superior's Name</th>
						<th>Salary</th>
						<th>Reason For Leaving</th>						
					</tr>
				    </thead>  
                    <!-- 2nd Row Content Inside Table -->
                     <tr>
                        <td><input type="text" name="work_lastJob_title1" class="transparent-input"></td>
                        <td><input type="text" name="work_Superiors_name1" class="transparent-input"></td>
                        <td>
                            <div style="text-align: center; font-weight: bold;">FROM:</div>
				            <input type="text" name="work_salary2" placeholder="From" pattern="[0-9]*" maxlength="11" style="width: 50%; padding: 3px; margin: 0 auto; display: block;">
                            <div style="text-align: center; font-weight: bold; margin-top: 5px;">TO:</div>
				            <input type="text" name="work_salary3" placeholder="to" pattern="[0-9]*" maxlength="11" style="width: 50%; padding: 3px; margin: 0 auto; display: block;">
                        </td>
                        <td><textarea id="reason-for-leaving" name="work_Reason_for_leaving1" rows="4"></textarea></td>
                    </tr>
                </tbody>                       
                </table><br><br>

                <!-- Licensure -->
                <table class="my-table">
                    <thead>
                        <caption style="font-size: 1.2em;"><strong>Licensure</strong></caption>
                        <tr>
                            <th>Type of Board Exam Take</th>
                            <th>Date of Exam</th>
                            <th>Rating</th>
                            <th>License No.</th>						
                        </tr>
				    </thead>
                    <tr>
							<td><input type="text" name="board_exam_type" class="transparent-input" required ></td>
							<td><input type="date" name="date_of_exam" class="transparent-input"></td>
							<td><input type="text" name="rating" class="transparent-input"></td>
							<td>
								<div class="file-input-wrapper">
                                <label for="license-photo-input" class="file-input-label"></label>
                                <input type="file" name="license_NO" accept="image/*" class="transparent-input" id="license-photo-input" >
                                <img id="license-photo-preview" name="license_NO" src="#" alt="Preview" style="display: none; width: 755px; height: 213px; object-fit: contain;">
                            </div>

							</td>
						</tr>
                        <tr>
							<td colspan="4" style="text-align: center;">
								HAVE YOU EVER BEEN CONVICTED OF A CRIME?<br><br>
								<input type="radio" id="convicted-yes" name="crime" value="yes">
								<label for="convicted-yes">Yes</label>
								<input type="radio" id="convicted-no" name="crime" value="no">
								<label for="convicted-no">No</label>
							</td>
						</tr>
						<tr>
							<td colspan="4" style="text-align: center;">
								If YES, explain no. of conviction/s, nature of offense/s leading to conviction/s, how recent such offense/s was/were committed sentence/s imposed, and type/s of rehabilitation.
								<br>
								<textarea id="convicted-explanation" name="crime_text" rows="4"></textarea>
							</td>
						</tr>
						<tr>
							<td colspan="4" style="text-align: center;">
								HAVE YOU EVER BEEN HOSPITALIZED/SOUGHT MEDICAL ATTENTION FOR THE PAST 6 MONTHS?<br><br>
								<input type="radio" id="convicted-yes" name="hospitalized" value="yes">
								<label for="convicted-yes">Yes</label>
								<input type="radio" id="convicted-no" name="hospitalized" value="no">
								<label for="convicted-no">No</label>
							</td>
						</tr>
						<tr>
							<td colspan="4" style="text-align: center;">
								If YES, please give details:
								<br>
								<textarea id="convicted-explanation" name="hospitalized_text" rows="4"></textarea>
							</td>
						</tr>
						<tr>
							<td colspan="4" style="text-align: center;">
								DO YOU HAVE ANY PRE-EXISTING HEALTH CONDITION OR AILMENT?<br><br>
								<input type="radio" id="convicted-yes" name="health_condition" value="yes">
								<label for="convicted-yes">Yes</label>
								<input type="radio" id="convicted-no" name="health_condition" value="no">
								<label for="convicted-no">No</label>
							</td>
						</tr>
						<tr>
							<td colspan="4" style="text-align: center;">
								If YES, please specify and give details:
								<br>
								<textarea id="convicted-explanation" name="health_condition_text" rows="4"></textarea>
							</td>
						</tr>
					</table>
				<br><br>
							
                        <!-- Function for photo to preview -->
                        <script>
            const fileInput = document.getElementById('license-photo-input');
            const previewImage = document.getElementById('license-photo-preview');

            fileInput.addEventListener('change', function(event) {
                const file = event.target.files[0];
                const reader = new FileReader();

                reader.onload = function(e) {
                    previewImage.src = e.target.result;
                    previewImage.style.display = 'block';
                };

                reader.readAsDataURL(file);
            });
        </script>

			
			<!-- CHARACTER REFERENCES -->
			<table class="my-table">
				<caption><strong>CHARACTER REFERENCES (Do not include Relatives; For Fresh Graduates, indicate School Registrar and Discipline Office)</strong></caption>
				<thead>
					<tr>
						<th class="name" style="background-color: #FFC000;">Name</th>
						<th class="contact-no" style="background-color: #FFC000;">Contact No.</th>
						<th class="company" style="background-color: #FFC000;">Company</th>
						<th class="position" style="background-color: #FFC000;">Position</th>
						<th class="relationship" style="background-color: #FFC000;">Relationship</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><input type="text" name="Name_reference" class="transparent-input" required ></td>
						<td><input type="text" name="contact_NO_reference" pattern="[0-9]*" maxlength="11" class="transparent-input"></td>
						<td><input type="text" name="reference_company" class="transparent-input"></td>
						<td><input type="text" name="reference_position" class="transparent-input"></td>
						<td><input type="text" name="reference_relationship" class="transparent-input"></td>
					</tr>
					<tr>
						<td><input type="text" name="Name_reference1" class="transparent-input"></td>
						<td><input type="text" name="contact_NO_reference1" pattern="[0-9]*" maxlength="11" class="transparent-input"></td>
						<td><input type="text" name="reference_company1" class="transparent-input"></td>
						<td><input type="text" name="reference_position1" class="transparent-input"></td>
						<td><input type="text" name="reference_relationship1" class="transparent-input"></td>
					</tr>
				</tbody>
			</table>
			<br><br>

			<!-- PERSON TO BE NOTIFIED IN CASE OF EMERGENCY -->
			<table class="my-table">
				<caption><strong>PERSON TO BE NOTIFIED IN CASE OF EMERGENCY</strong></caption>
				<thead>
					<tr>
						<th class="name" style="background-color: #FFC000;">Name</th>
						<th class="contact-no" style="background-color: #FFC000;">Contact No.</th>
						<th class="address" style="background-color: #FFC000;">Address</th>
						<th class="relationship" style="background-color: #FFC000;">Relationship</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><input type="text" name="Name_emergency" class="transparent-input" required ></td>
						<td><input type="text" name="contact_NO_emergency" pattern="[0-9]*" maxlength="11" class="transparent-input"></td>
						<td><input type="text" name="address_emergency" class="transparent-input"></td>
						<td><input type="text" name="relationship_emergency" class="transparent-input"></td>
					</tr>
				</tbody>
			</table>
			<br><br>
			
			<!-- CERTIFICATION -->
			<div class="certification-wrapper">
				<p class="certification-text" style="text-align: center;">"I hereby certify that all the above statements are true and correct. If any information relevant to or causing my employment with SCCI is later found to be false or incorrect, I may be subject to immediate dismissal, if then employed in any capacity."</p>
			</div>
			<div class="certification-card" style="background-color: #FFC000;">
			<table>
			<tr>
                    <td><strong>Printed Name:</strong></td>
                    <td><input type="text" name="e_signature_name" required></td>
                </tr>

				<tr>
					<td><strong>Signature:</strong></td>
					<td><input type="file" name="esig_name" ></td>
				</tr>
				<tr>
					<td><strong>Date:</strong></td>
					<td><input type="date" name="name_esignature"></td>
				</tr>
			</table>
			</div>
			<br>

               
    <!-- end -->
	<div style="text-align: center;">
	<input type="submit" name="submit" value="Save Form" style="font-size: 1.2em; padding: 10px; border-radius: 5px; background-color: #FFC000;">
	</div><br><br>

	<!-- FOOTER -->
	<div style="text-align: center; background-color: #FFC000; padding: 10px; font-size: 14px; margin-top: 10px; display: inline-block; width: 100%;"> © 2023 Scheirman Construction Consolidated Inc.</div>

      <!-- end of forms -->
		</form>
	</thead> 	
</table>

		<div class="overlay"></div>
  <table>
  </table>
		<script>
			// show/hide overlay when the table is focused
			const table = document.querySelector('table');
			const overlay = document.querySelector('.overlay');
			
			table.addEventListener('focusin', () => {
			overlay.style.display = 'block';
			});
			
			table.addEventListener('focusout', () => {
			overlay.style.display = 'none';
			});
		</script>
		
		<script>
        // script to display image uploaded in signature
			function displayImage() {
				var input = document.getElementById('image');
				var img = document.getElementById('id-picture');
				img.src = URL.createObjectURL(input.files[0]);
				img.onload = function() {
					var container = document.querySelector('.picture-container');
					var widthRatio = container.offsetWidth / img.width;
					var heightRatio = container.offsetHeight / img.height;
					var ratio = Math.min(widthRatio, heightRatio);
					img.style.width = img.width * ratio + 'px';
					img.style.height = img.height * ratio + 'px';
				};
			}
		</script>
	</body>
</html>

