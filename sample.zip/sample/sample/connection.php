<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require 'C:/xampp/htdocs/sample/sample/vendor/autoload.php';


$host = "localhost";
$user = "root";
$password = "";
$database = "epiz_34174136_application_form";

// Create connection
$conn = mysqli_connect($host, $user, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

echo "";
?>