<?php


require_once('connection.php');



// check if the id is set in the URL
if(isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // build the SQL query to fetch the details of the submission
    $query = " SELECT character_reference.id,
    character_reference.Name_reference,
    character_reference.contact_NO_reference,
    character_reference.reference_company,
    character_reference.reference_position,
    character_reference.reference_relationship,
    character_reference.Name_reference1,
    character_reference.contact_NO_reference1,
    character_reference.reference_company1,
    character_reference.reference_position1,
    character_reference.reference_relationship1,
    checkbox.id,
    checkbox.crime,
    checkbox.crime_text,
    checkbox.hospitalized,
    checkbox.hospitalized_text,
    checkbox.health_condition,
    checkbox.health_condition_text,
    educational_background.id,
    educational_background.post_graduate_from,
    educational_background.post_graduate_to,
    educational_background.post_graduate_course,
    educational_background.post_graduate_school,
    educational_background.tertiary_from,
    educational_background.tertiary_to,
    educational_background.tertiary_course,
    educational_background.tertiary_school,
    educational_background.vocational_from,
    educational_background.vocational_to,
    educational_background.vocational_course,
    educational_background.vocational_school,
    educational_background.high_school_from,
    educational_background.high_school_to,
    educational_background.high_school_course,
    educational_background.high_school_school,
    e_signature.id,
    e_signature.e_signature_name,
    e_signature.esig_name,
    e_signature.name_esignature,
    family_background.id,
    family_background.fam_name,
    family_background.fam_relationship,
    family_background.fam_age,
    family_background.fam_birth_date,
    family_background.fam_civil_status,
    family_background.fam_occupation,
    family_background.fam_employer_school,
    family_background.fam_name1,
    family_background.fam_relationship1,
    family_background.fam_age1,
    family_background.fam_birth_date1,
    family_background.fam_civil_status1,
    family_background.fam_occupation1,
    family_background.fam_employer_school1,
    family_background.fam_name2,
    family_background.fam_relationship2,
    family_background.fam_age2,
    family_background.fam_birth_date2,
    family_background.fam_civil_status2,
    family_background.fam_occupation2,
    family_background.fam_employer_school2,
    family_background.fam_name3,
    family_background.fam_relationship3,
    family_background.fam_age3,
    family_background.fam_birth_date3,
    family_background.fam_civil_status3,
    family_background.fam_occupation3,
    family_background.fam_employer_school3,
    family_background.fam_name4,
    family_background.fam_relationship4,
    family_background.fam_age4,
    family_background.fam_birth_date4,
    family_background.fam_civil_status4,
    family_background.fam_occupation4,
    family_background.fam_employer_school4,
    family_background.fam_name5,
    family_background.fam_relationship5,
    family_background.fam_age5,
    family_background.fam_birth_date5,
    family_background.fam_civil_status5,
    family_background.fam_occupation5,
    family_background.fam_employer_school5,
    licensure.id,
    licensure.board_exam_type,
    licensure.date_of_exam,
    licensure.rating,
    licensure.license_NO,
    nature_of_application.id,
    nature_of_application.scci_website,
    nature_of_application.walk_in,
    nature_of_application.indeed,
    nature_of_application.jobstreet,
    nature_of_application.facebook,
    nature_of_application.referred_by,
    personal_information.id,
    personal_information.surName,
    personal_information.gender,
    personal_information.given_name,
    personal_information.middle_name,
    personal_information.middle_initial,
    personal_information.nickName,
    personal_information.civil_status,
    personal_information.present_address,
    personal_information.permanent_address,
    personal_information.birth_date,
    personal_information.birth_place,
    personal_information.birth_place,
    personal_information.birth_place,
    personal_information.religion,
    personal_information.sss_NO,
    personal_information.pag_ibig_NO,
    personal_information.philhealth_NO,
    personal_information.tin,
    personal_information.tax_status,
    personal_information.Contact_NO,
    personal_information.Contact_NO1,
    personal_sheet.id,
    personal_sheet.date_accomplished,
    personal_sheet.n_application,
    personal_sheet.image,
    person_emergency_contact.id,
    person_emergency_contact.Name_emergency,
    person_emergency_contact.contact_NO_emergency,
    person_emergency_contact.address_emergency,
    person_emergency_contact.relationship_emergency,
    position_apply.id,
    position_apply.choice1,
    position_apply.choice2,
    work_experience.id,
    work_experience.work_company_name,
    work_experience.work_contact_NO,
    work_experience.work_complete_address,
    work_experience.work_employment_from,
    work_experience.work_employment_to,
    work_experience.work_lastJob_title,
    work_experience.work_Superiors_name,
    work_experience.work_list_duties_promotion,
    work_experience.work_salary,
    work_experience.work_salary1,
    work_experience.work_Reason_for_leaving,
    work_experience.work_list_duties_promotion,
    work_experience.work_company_name1,
    work_experience.work_contact_NO1,
    work_experience.work_complete_address1,
    work_experience.work_employment_from1,
    work_experience.work_employment_to1,
    work_experience.work_lastJob_title1,
    work_experience.work_Superiors_name1,
    work_experience.work_salary2,
    work_experience.work_salary3,
    work_experience.work_Reason_for_leaving1,
    work_experience.work_list_duties_promotion1
    
    FROM  character_reference
    LEFT JOIN checkbox ON character_reference.id = checkbox.id
    LEFT JOIN educational_background ON character_reference.id = educational_background.id
    LEFT JOIN e_signature ON character_reference.id = e_signature.id
    LEFT JOIN family_background ON character_reference.id = family_background.id
    LEFT JOIN licensure ON character_reference.id = licensure.id
    LEFT JOIN nature_of_application ON character_reference.id = nature_of_application.id
    LEFT JOIN personal_information ON character_reference.id = personal_information.id
    LEFT JOIN personal_sheet ON character_reference.id = personal_sheet.id
    LEFT JOIN person_emergency_contact ON character_reference.id = person_emergency_contact.id
    LEFT JOIN position_apply ON character_reference.id = position_apply.id
    LEFT JOIN upload ON character_reference.id = upload.id
    LEFT JOIN work_experience ON character_reference.id = work_experience.id
    WHERE character_reference.id = '$id'";

 // execute the query
 $result = mysqli_query($conn, $query);

  // check if there is a result
  if(mysqli_num_rows($result) > 0) {
    // fetch the data from the result set
    $row = mysqli_fetch_assoc($result);
  }
}


?>


<!DOCTYPE html>
<html>
<head>
	<title>Personal Information Sheet</title>
	<link rel="stylesheet" type="text/css" href="forms.css">
    <link rel="icon" type="image/png" href="img/lg.png">
</head>
<body>	

<!-- SCHEIRMAN'S LOGO  -->

<div style="text-align: center;">
  <img src="images/logo.png" alt="Image Description" style="width: 500px;"><br>
</div>

<!--code that will just display the values in the database based on the ID  -->
<!-- personal sheet -->
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data" >
	<h1>PERSONAL INFORMATION SHEET</h1>
		<p>Date Accomplished: <input type="date" name="date_accomplished" value="<?php echo $row['date_accomplished']; ?>"disabled readonly></p>
		<p>Nature of Application: <input type="text" name="n_application" style="border: none;" placeholder="Nature of Application" value="<?php echo $row['n_application']; ?>"disabled readonly>
		<p>
			<label><input type="checkbox" name="scci_website" value="SCCI WEBSITE" <?php echo $row['scci_website'] == 1 ? 'checked' : ''; ?> disabled> SCCI WEBSITE</label>
			<label><input type="checkbox" name="walk_in" value="Walk-In" <?php echo $row['walk_in'] == 1 ? 'checked' : ''; ?> disabled> Walk-In</label>
			<label><input type="checkbox" name="indeed" value="Indeed" <?php echo $row['indeed'] == 1 ? 'checked' : ''; ?> disabled> Indeed</label>
			<label><input type="checkbox" name="jobstreet" value="Jobstreet" <?php echo $row['jobstreet'] == 1 ? 'checked' : ''; ?> disabled> Jobstreet</label>
			<label style="position: relative;">
			<input type="checkbox" name="facebook" value="Facebook" <?php echo $row['facebook'] == 1 ? 'checked' : ''; ?> disabled> Facebook</label>

			<?php 
          // display image in picture-container div
            echo '<div class="picture-container" style="width: 300px; height: 300px; margin-top: 10px;">';
            if (!empty($row['image'])) {
                echo '<img src="data:image/jpeg;base64,'.base64_encode($row['image']).'" alt="ID Picture" style="width: 100%; height: 100%; object-fit: contain;">';
            } else {
                echo '<img src="#" alt="ID Picture" width="500" height="500">';
            }
            echo '</div>';
            ?>
            
        </label>
		</p>
		<p>
			<label><input type="checkbox" name="referred_by" value="Referred by:">Referred By:</label>
			<input type="text" name="referred_by" value="<?php echo $row['referred_by']; ?>" style="border: none;"readonly >
		</p>
		<p>
			<label>Position Applying For:</label><br>
			<span style="text-decoration: underline;">1st Choice:</span> <input type="text" name="choice1" style="border: none;" value="<?php echo $row['choice1']; ?>" readonly>
			<span style="text-decoration: underline;">2nd Choice:</span> <input type="text" name="choice2" style="border: none;" value="<?php echo $row['choice2']; ?>" readonly>
		</p>

			<!-- TABLE FOR PERSONAL INFORMATION -->
			<h2>Personal Information</h2>
			<table class="my-table">
				<!-- NAME -->	
				<thead>
					<tr>
						<th class="surName" style="background-color: #FFC000;">Surname</th>
						<th class="given_name" style="background-color: #FFC000;">Given Name</th>
						<th class="middle_name" style="background-color: #FFC000;">Middle Name</th>
						<th class="middle_initial" style="background-color: #FFC000;">Middle Initial</th>
						<th class="nickName" style="background-color: #FFC000;">Nickname</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><input type="text" name="surName" value="<?php echo $row['surName']; ?>" ></td>
						<td><input type="text" name="given_name" value="<?php echo $row['given_name']; ?>"></td>
						<td><input type="text" name="middle_name" value="<?php echo $row['middle_name']; ?>"></td>
						<td><input type="text" name="middle_initial" value="<?php echo $row['middle_initial']; ?>"></td>
						<td><input type="text" name="nickName" value="<?php echo $row['nickName']; ?>"></td>
					</tr>
				</tbody>

				  <!-- ADDRESS -->
				  <tr>
					<th class="present_address" style="background-color: #FFC000;">Address:</th>
						<td colspan="2">
							<label for="present-address" >Present Address: </label>
							<input type="text" name="present_address" value="<?php echo $row['present_address']; ?>" readonly>
						</td>   
						<td colspan="2">
							<label for="Contact_NO">Contact Number: </label>
							<input type="tel" name="Contact_NO" pattern="[0-9]*" maxlength="11" value="<?php echo $row['Contact_NO']; ?>" readonly>
						</td>
				  </tr>							  
				  <tr>
					<th class="permanent_address-address" style="background-color: #FFC000;">Address:</th>
						<td colspan="2">
							<label for="permanent-address">Permanent Address: </label>
							<input type="text" name="permanent_address" value="<?php echo $row['permanent_address']; ?>" readonly>
						</td>
						<td colspan="2">
							<label for="Contact_NO1">Contact Number: </label>
							<input type="tel" name="Contact_NO1" pattern="[0-9]*" maxlength="11" value="<?php echo $row['Contact_NO1']; ?>" readonly>
						</td>
				  </tr>
				
				  <!-- OTHER INFORMATION -->
				  <thead>
					<tr>
					  <th class="birth_date" style="background-color: #FFC000;">Birthdate</th>
					  <th class="birth_place" style="background-color: #FFC000;">Birthplace</th>
					  <th class="civil_status" style="background-color: #FFC000;">Civil Status</th>
					  <th class="gender" style="background-color: #FFC000;">Gender</th>
					  <th class="religion" style="background-color: #FFC000;">Religion</th>
					</tr>
				  </thead>	
					<tr>
						<td><input type="date" name="birth_date" id="birth_date" value="<?php echo $row['birth_date']; ?>"readonly></td>
						<td><input type="text" name="birth_place" id="birth_place" value="<?php echo $row['birth_place']; ?>"readonly> </td>
						<td><input type="text" name="civil_status" id="civil_status" value="<?php echo $row['civil_status']; ?>"readonly> </td>
						<td style="text-align: center;">
                            <select name="gender">
                            <option value="male" <?php echo strtolower($row['gender']) == 'male' ? 'selected' : ''; ?> disabled>Male</option>
                            <option value="female" <?php echo strtolower($row['gender']) == 'female' ? 'selected' : ''; ?> disabled>Female</option>
                            <option value="prefer_not_to_say" <?php echo strtolower($row['gender']) == 'prefer_not_to_say' ? 'selected' : ''; ?> disabled>Prefer not to say</option>
                        </select>

                        </td>
						<td><input type="text" name="religion" id="religion" value="<?php echo $row['religion']; ?>"readonly> </td>
					</tr>
				
				  <!-- ID's -->
				  <thead>
					<tr>
					  <th class="sss" style="background-color: #FFC000;">SSS No.:</th>
					  <th class="pagibig" style="background-color: #FFC000;">PAG-IBIG No.:</th>
					  <th class="philhealth" style="background-color: #FFC000;">Philhealth No.:</th>
					  <th class="tin" style="background-color: #FFC000;">TIN:</th>
					  <th class="tax-status" style="background-color: #FFC000;">Tax Status:</th>
					</tr>
				  </thead>	
				  <tr>
					<td><input type="text" name="sss_NO" pattern="[0-9]*" maxlength="11" value="<?php echo $row['sss_NO']; ?>" readonly> </td>
					<td><input type="text" name="pag_ibig_NO" pattern="[0-9]*" maxlength="11" value="<?php echo $row['pag_ibig_NO']; ?>"readonly> </td>
					<td><input type="text" name="philhealth_NO" pattern="[0-9]*" maxlength="11" value="<?php echo $row['philhealth_NO']; ?>"readonly> </td>
					<td><input type="text" name="tin" pattern="[0-9]*" maxlength="11" value="<?php echo $row['tin']; ?>"readonly>  </td>
					<td><input type="text" name="tax_Status" pattern="[0-9]*" maxlength="11" value="<?php echo $row['tax_status']; ?>"readonly ></td>
					</tr>
			</table><br>

				<!-- FAMILY BACKGROUND -->
				<table style="border-collapse: collapse; border: 2px solid black;">
					<caption style="font-size: 1.2em;"><strong>FAMILY BACKGROUND (For Single Employees: Parents, Siblings, Children; For Married Employees: Spouse, Children)</strong></caption>
					<thead>
						<table class="my-table">
							<thead>
								<tr>
								  <th class="age-column" style="background-color: #FFC000;">Name</th>
								  <th class="relationship" style="background-color: #FFC000;">Relationship:</th>
								  <th class="age-column" style="background-color: #FFC000;">Age</th>
								  <th class="birthdate" style="background-color: #FFC000;">Birthdate</th>
								  <th class="civil-status" style="background-color: #FFC000;">Civil Status</th>
								  <th style="background-color: #FFC000;">Occupation</th>
								  <th style="background-color: #FFC000;">Employer/School</th>
								</tr>
							  </thead>	
							<tbody>
							<tr>
							<td><input type="text" name="fam_name" class="transparent-input" value="<?php echo $row['fam_name']; ?>" readonly></td>
								<td class="relationship"><input type="text" name="fam_relationship" value="<?php echo $row['fam_relationship']; ?>"readonly></td>
								<td class="age-column"><input type="text" name="fam_age" maxlength="2" value="<?php echo $row['fam_age']; ?>"readonly></td>
								<td class="birthdate"><input type="date" name="fam_birth_date" id="birthdate"value="<?php echo $row['fam_birth_date']; ?>"readonly></td>
								<td class="civil-status"><input type="text" name="fam_civil_status" value="<?php echo $row['fam_civil_status']; ?>"readonly></td>
								<td><input type="text" name="fam_occupation" value="<?php echo $row['fam_occupation']; ?>"readonly></td>
								<td><input type="text" name="fam_employer_school" value="<?php echo $row['fam_employer_school']; ?>"readonly></td>
							</tr>
							<tr>
							    <td><input type="text" name="fam_name1" class="transparent-input"value="<?php echo $row['fam_name1']; ?>" readonly></td>
								<td class="relationship"><input type="text" name="fam_relationship1" value="<?php echo $row['fam_relationship1']; ?>"readonly></td>
								<td class="age-column"><input type="text" name="fam_age1"maxlength="2" value="<?php echo $row['fam_age1']; ?>"readonly></td>
								<td class="birthdate"><input type="date" name="fam_birth_date1" id="birthdate" value="<?php echo $row['fam_birth_date1']; ?>"readonly></td>
								<td class="civil-status"><input type="text" name="fam_civil_status1" value="<?php echo $row['fam_civil_status1']; ?>"readonly></td>
								<td><input type="text" name="fam_occupation1" class="transparent-input" value="<?php echo $row['fam_occupation1']; ?>"readonly></td>
								<td><input type="text" name="fam_employer_school1" class="transparent-input"value="<?php echo $row['fam_employer_school1']; ?>"readonly></td>
							</tr>
							<tr>
							    <td><input type="text" name="fam_name2" class="transparent-input"value="<?php echo $row['fam_name2']; ?>" readonly></td>
								<td class="relationship"><input type="text" name="fam_relationship2" value="<?php echo $row['fam_relationship2']; ?>"readonly></td>
								<td class="age-column"><input type="text" name="fam_age2"maxlength="2" value="<?php echo $row['fam_age2']; ?>"readonly></td>
								<td class="birthdate"><input type="date" name="fam_birth_date2" id="birthdate" value="<?php echo $row['fam_birth_date2']; ?>"readonly></td>
								<td class="civil-status"><input type="text" name="fam_civil_status2" value="<?php echo $row['fam_civil_status2']; ?>"readonly></td>
								<td><input type="text" name="fam_occupation2" class="transparent-input" value="<?php echo $row['fam_occupation2']; ?>"readonly></td>
								<td><input type="text" name="fam_employer_school2" class="transparent-input"value="<?php echo $row['fam_employer_school2']; ?>"readonly></td>
							</tr>
							<tr>
							<td><input type="text" name="fam_name3" class="transparent-input" value="<?php echo $row['fam_name3']; ?>" readonly></td></td>
								<td class="relationship"><input type="text" name="fam_relationship3" class="transparent-input" value="<?php echo $row['fam_relationship3']; ?>" readonly></td>
								<td class="age-column"><input type="text" name="fam_age3" maxlength="2" class="transparent-input" value="<?php echo $row['fam_age3']; ?>" readonly></td>
								<td class="birthdate"><input type="date" name="fam_birth_date3" id="birthdate" value="<?php echo $row['fam_birth_date3']; ?>" readonly></td>
								<td class="civil-status"><input type="text" name="fam_civil_status3" class="transparent-input" value="<?php echo $row['fam_civil_status3']; ?>" readonly></td>
								<td><input type="text" name="fam_occupation3" class="transparent-input" value="<?php echo $row['fam_occupation3']; ?>" readonly></td>
								<td><input type="text" name="fam_employer_school3" class="transparent-input" value="<?php echo $row['fam_employer_school3']; ?>" readonly></td>
							</tr>
							<tr>
							<td><input type="text" name="fam_name4" class="transparent-input" value="<?php echo $row['fam_name4']; ?>" readonly></td>
								<td class="relationship"><input type="text" name="fam_relationship4" class="transparent-input"value="<?php echo $row['fam_relationship4']; ?>" readonly></td>
								<td class="age-column"><input type="text" name="fam_age4" maxlength="2" class="transparent-input" value="<?php echo $row['fam_age4']; ?>" readonly></td>
								<td class="birthdate"><input type="date" name="fam_birth_date4" id="birthdate" value="<?php echo $row['fam_birth_date4']; ?>" readonly></td>
								<td class="civil-status"><input type="text" name="fam_civil_status4" class="transparent-input" value="<?php echo $row['fam_civil_status4']; ?>" readonly></td>
								<td><input type="text" name="fam_occupation4" class="transparent-input" value="<?php echo $row['fam_occupation4']; ?>" readonly></td>
								<td><input type="text" name="fam_employer_school4" class="transparent-input" value="<?php echo $row['fam_employer_school4']; ?>" readonly></td>
							</tr>
							</tbody>
						</table>
						<br><br>
			
				<!-- EDUCATIONAL BACKGROUND -->
				<table class="my-table" style="border-collapse: collapse; border: 2px solid black;">
					<caption style="font-size: 1.2em;"><strong>Educational Background</strong></caption>
					<thead>
						<tr>
							<th colspan="2" style="border: 2px solid black; padding: 8px; background-color: #FFC000;"></th>
							<th style="border: 2px solid black; padding: 8px; background-color: #FFC000;">From</th>
							<th style="border: 2px solid black; padding: 8px; background-color: #FFC000;">To</th>
							<th style="border: 2px solid black; padding: 8px; background-color: #FFC000;">Course/Degree</th>
							<th style="border: 2px solid black; padding: 8px; background-color: #FFC000;">School Address</th>
						</tr>
					</thead>
					<tbody>
					<tr>
						<td colspan="2" style="border: 2px solid black; padding: 8px;">Post Graduate</td>
						<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" name="post_graduate_from" value="<?php echo $row['post_graduate_from']; ?>"readonly></td>
						<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" name="post_graduate_to"value="<?php echo $row['post_graduate_to']; ?>"readonly></td>
						<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" name="post_graduate_course" value="<?php echo $row['post_graduate_course']; ?>"readonly></td>
						<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" style="width: 300px;" name="post_graduate_school"value="<?php echo $row['post_graduate_school']; ?>"readonly></td>
					</tr> 
					<tr>
						<td colspan="2" style="border: 2px solid black; padding: 8px;">Tertiary</td>
						<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" name="tertiary_from" value="<?php echo $row['tertiary_from']; ?>"readonly></td>
						<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" name="tertiary_to"value="<?php echo $row['tertiary_to']; ?>"readonly></td>
						<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" name="tertiary_course"value="<?php echo $row['tertiary_course']; ?>"readonly></td>
						<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" style="width: 300px;" name="tertiary_school"value="<?php echo $row['tertiary_school']; ?>"readonly></td>
					</tr>
					<tr>
						<td colspan="2" style="border: 2px solid black; padding: 8px;">Vocational</td>
						<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" name="vocational_from" value="<?php echo $row['vocational_from']; ?>"readonly></td>
						<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" name="vocational_to" value="<?php echo $row['vocational_to']; ?>"readonly></td>
						<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" name="vocational_course"  value="<?php echo $row['vocational_course']; ?>"readonly></td>
						<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" style="width: 300px;" name="vocational_school"  value="<?php echo $row['vocational_school']; ?>"readonly></td>
					</tr>
					<tr>
					<td colspan="2" style="border: 2px solid black; padding: 8px;">High School</td>
					<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" name="high_school_from" value="<?php echo $row['high_school_from']; ?>"readonly></td>
					<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" name="high_school_to"value="<?php echo $row['high_school_to']; ?>"readonly></td>
					<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" name="high_school_course" value="<?php echo $row['high_school_course']; ?>"readonly></td>
					<td style="border: 2px solid black; padding: 8px;"><input type="text" class="transparent-input" style="width: 300px;" name="high_school_school"  value="<?php echo $row['high_school_school']; ?>"readonly></td>
					</tr>
				</tbody>
				</table>
                <br><br>

                <!-- WORK EXPERIENCE -->
                <table class="my-table">
                	<thead>
                    <caption style="font-size: 1.2em;"><strong>Work Experience (Please list your work experiences beginning with your most recent job.)</strong></caption>
					<tr>
						<th>Company Name</th>
						<th>Contact No.</th>
						<th>Complete Address</th>
						<th>Employment Date</th>						
					</tr>
				    </thead>
                <tbody>
                    <!-- Content Inside Table -->
                    <tr>
                        <td><input type="text" name="work_company_name" class="transparent-input" value="<?php echo $row['work_company_name']; ?>"readonly></td>
                        <td><input type="text" name="work_contact_NO" pattern="[0-9]*" maxlength="11" class="transparent-input"value="<?php echo $row['work_contact_NO']; ?>"readonly></td>
                       <td>
    <textarea id="reason-for-leaving" name="work_complete_address" rows="4" cols="50" readonly style="resize: none; margin: 0 auto; display: block;"><?php echo $row['work_complete_address']; ?></textarea>
</td>

                        <td>
                            <div style="text-align: center; font-weight: bold;">FROM:</div>
                            <input type="date" name="work_employment_from" value="<?php echo $row['work_employment_from']; ?>" readonly style="width: 50%; padding: 3px; margin: 0 auto; display: block;">
                            <div style="text-align: center; font-weight: bold; margin-top: 5px;">TO:</div>
                            <input type="date" name="work_employment_to" value="<?php echo $row['work_employment_to']; ?>" readonly style="width: 50%; padding: 3px; margin: 0 auto; display: block;">
                        </td>
                    </tr>
                 <thead>
					<tr>
						<th>List Job Title/Effective Date:</th>
						<th>Superior's Name</th>
						<th>Salary</th>
						<th>Reason For Leaving</th>						
					</tr>
				    </thead>    
                    <!-- 2nd Row Content Inside Table -->
                     <tr>
                        <td><input type="text" name="work_lastJob_title" value="<?php echo $row['work_lastJob_title']; ?>"readonly class="transparent-input" ></td>
                        <td><input type="text" name="work_Superiors_name" value="<?php echo $row['work_Superiors_name']; ?>"readonly pattern="[0-9]*" maxlength="11" class="transparent-input"></td>
                        <td>
                            <div style="text-align: center; font-weight: bold;">FROM:</div>
				            <input type="text" name="work_salary" value="<?php echo $row['work_salary']; ?>"readonly placeholder="From" pattern="[0-9]*" maxlength="11" style="width: 50%; padding: 3px; margin: 0 auto; display: block;">
                            <div style="text-align: center; font-weight: bold; margin-top: 5px;">TO:</div>
				            <input type="text" name="work_salary1" value="<?php echo $row['work_salary1']; ?>"readonly placeholder="From" pattern="[0-9]*" maxlength="11" style="width: 50%; padding: 3px; margin: 0 auto; display: block;">
                        </td>
                        <td><textarea id="reason-for-leaving" name="work_Reason_for_leaving" rows="4" readonly><?php echo $row['work_Reason_for_leaving']; ?></textarea></td>
                    </tr>
                </tbody>                       
                </table><br><br>
                
                <!-- WORK EXPERIENCE 2 -->
                <table class="my-table">
                	<thead>
					<tr>
						<th>Company Name</th>
						<th>Contact No.</th>
						<th>Complete Address</th>
						<th>Employment Date</th>						
					</tr>
				    </thead>
                <tbody>
                    <!-- Content Inside Table -->
                    <tr>
                        <td><input type="text" name="work_company_name1" class="transparent-input"readonly value="<?php echo $row['work_company_name1']; ?>"></td>
                        <td><input type="text" name="work_contact_NO1" pattern="[0-9]*" maxlength="11" class="transparent-input"readonly value="<?php echo $row['work_contact_NO1']; ?>"></td>
                        <td>
    <textarea id="reason-for-leaving" name="work_complete_address1" rows="4" cols="50" readonly style="resize: none; margin: 0 auto; display: block;"><?php echo $row['work_complete_address1']; ?></textarea>
</td>

                        <td>
                            <div style="text-align: center; font-weight: bold;">FROM:</div>
                            <input type="date" name="work_employment_from1" value="<?php echo $row['work_employment_from1']; ?>"readonly placeholder="From" style="width: 50%; padding: 3px; margin: 0 auto; display: block;">
                            <div style="text-align: center; font-weight: bold; margin-top: 5px;">TO:</div>
                            <input type="date" name="work_employment_to1" value="<?php echo $row['work_employment_to1']; ?>"readonly placeholder="To" style="width: 50%; padding: 3px; margin: 0 auto; display: block;">
                        </td>
                    </tr>
                 <thead>
					<tr>
						<th>List Job Title/Effective Date:</th>
						<th>Superior's Name</th>
						<th>Salary</th>
						<th>Reason For Leaving</th>						
					</tr>
				    </thead>  
                    <!-- 2nd Row Content Inside Table -->
                     <tr>
                        <td><input type="text" name="work_lastJob_title1" class="transparent-input" value="<?php echo $row['work_lastJob_title1']; ?>" readonly> </td>
                        <td><input type="text" name="work_Superiors_name1" pattern="[0-9]*" maxlength="11" value="<?php echo $row['work_Superiors_name1']; ?>" readonly class="transparent-input"></td>
                        <td>
                            <div style="text-align: center; font-weight: bold;">FROM:</div>
				            <input type="text" name="work_salary2" value="<?php echo $row['work_salary2']; ?> "readonly placeholder="From" pattern="[0-9]*" maxlength="11" style="width: 50%; padding: 3px; margin: 0 auto; display: block;">
                            <div style="text-align: center; font-weight: bold; margin-top: 5px;">TO:</div>
				            <input type="text" name="work_salary3" value="<?php echo $row['work_salary3']; ?>"readonly placeholder="From" pattern="[0-9]*" maxlength="11" style="width: 50%; padding: 3px; margin: 0 auto; display: block;">
                        </td>
                        <td><textarea id="reason-for-leaving" name="work_Reason_for_leaving1" rows="4" readonly><?php echo $row['work_Reason_for_leaving1']; ?></textarea></td>
                    </tr>
                </tbody>                       
                </table><br><br>

                <!-- Licensure -->
                <table class="my-table">
                    <thead>
                        <caption style="font-size: 1.2em;"><strong>Licensure</strong></caption>
                        <tr>
                            <th>Type of Board Exam Take</th>
                            <th>Date of Exam</th>
                            <th>Rating</th>
                            <th>License No.</th>						
                        </tr>
				    </thead>
                    <tr>
							<td><input type="text" name="board_exam_type" value="<?php echo $row['board_exam_type']; ?>" readonly class="transparent-input"></td>
							<td><input type="date" name="date_of_exam" value="<?php echo $row['date_of_exam']; ?>" readonly ="transparent-input"></td>
							<td><input type="text" name="rating" value="<?php echo $row['rating']; ?>" readonly  class="transparent-input"></td>
                                <td>
                               <?php
                        if (!empty($row['license_NO'])) {
                            echo '<img src="data:image/jpeg;base64,'.base64_encode($row['license_NO']).'" alt="ID Picture" style="width: 30%; height: 30%; object-fit: contain;">';
                        } else {
                            echo '<img src="#" alt="ID Picture" width="50" height="50">';
                        }
                        ?>

                                </td>
						</tr>
                        <tr>
							<td colspan="4" style="text-align: center;">
								HAVE YOU EVER BEEN CONVICTED OF A CRIME?<br><br>
								<input type="radio" id="convicted-yes" name="crime" value="yes" <?php echo $row['crime'] == 'yes' ? 'checked' : ''; ?> disabled >
								<label for="convicted-yes" value="yes" >Yes</label>
								<input type="radio" id="convicted-no" name="crime" value="no" <?php echo $row['crime'] == 'no' ? 'checked' : ''; ?> disabled >
								<label for="convicted-no" >No</label>
							</td>
						</tr>
						<tr>
							<td colspan="4" style="text-align: center;">
								If YES, explain no. of conviction/s, nature of offense/s leading to conviction/s, how recent such offense/s was/were committed sentence/s imposed, and type/s of rehabilitation.
								<br>
								<textarea id="convicted-explanation" name="crime_text" rows="4" readonly> <?php echo $row['crime_text']; ?></textarea>
							</td>
						</tr>
						<tr>
							<td colspan="4" style="text-align: center;">
								HAVE YOU EVER BEEN HOSPITALIZED/SOUGHT MEDICAL ATTENTION FOR THE PAST 6 MONTHS?<br><br>
								<input type="radio" id="convicted-yes" name="hospitalized" value="yes"  <?php echo $row['hospitalized'] == 'yes' ? 'checked' : ''; ?> disabled>
								<label for="convicted-yes" >Yes</label>
								<input type="radio" id="convicted-no" name="hospitalized" value="no" <?php echo $row['hospitalized'] == 'no' ? 'checked' : ''; ?> disabled>
								<label for="convicted-no"  >No</label>
							</td>
						</tr>
						<tr>
							<td colspan="4" style="text-align: center;">
								If YES, please give details:
								<br>
								<textarea id="convicted-explanation" name="hospitalized_text" rows="4" readonly> <?php echo $row['hospitalized_text']; ?> </textarea>
							</td>
						</tr>
						<tr>
							<td colspan="4" style="text-align: center;">
								DO YOU HAVE ANY PRE-EXISTING HEALTH CONDITION OR AILMENT?<br><br>
								<input type="radio" id="convicted-yes" name="health_condition" value="yes" <?php echo $row['health_condition'] == 'yes' ? 'checked' : ''; ?> disabled>
								<label for="convicted-yes">Yes</label>
								<input type="radio" id="convicted-no" name="health_condition" value="no" <?php echo $row['health_condition'] == 'no' ? 'checked' : ''; ?> disabled>
								<label for="convicted-no">No</label>
							</td>
						</tr>
						<tr>
							<td colspan="4" style="text-align: center;">
								If YES, please specify and give details:
								<br>
								<textarea id="convicted-explanation" name="health_condition_text" rows="4" readonly> <?php echo $row['health_condition_text']; ?></textarea>
							</td>
						</tr>
					</table>
				<br><br>
							
				 <!-- Function for photo to preview -->
				<script>
					document.getElementById('license-photo-input').addEventListener('change', function(event) {
						var file = event.target.files[0];
						var previewImage = document.getElementById('license-photo-preview');
						
						if (file) {
						var reader = new FileReader();
						
						reader.onload = function() {
							previewImage.src = reader.result;
							previewImage.style.display = 'block';
						};
						
						reader.readAsDataURL(file);
						} else {
						previewImage.src = '#';
						previewImage.style.display = 'none';
						}
					});
					</script>
			
			<!-- CHARACTER REFERENCES -->
			<table class="my-table">
				<caption><strong>CHARACTER REFERENCES (Do not include Relatives; For Fresh Graduates, indicate School Registrar and Discipline Office)</strong></caption>
				<thead>
					<tr>
						<th class="name" style="background-color: #FFC000;">Name</th>
						<th class="contact-no" style="background-color: #FFC000;">Contact No.</th>
						<th class="company" style="background-color: #FFC000;">Company</th>
						<th class="position" style="background-color: #FFC000;">Position</th>
						<th class="relationship" style="background-color: #FFC000;">Relationship</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><input type="text" name="Name_reference" class="transparent-input" value="<?php echo $row['Name_reference']; ?>" readonly></td>
						<td><input type="text" name="contact_NO_reference" pattern="[0-9]*" maxlength="11" class="transparent-input" value="<?php echo $row['contact_NO_reference']; ?>" readonly></td>
						<td><input type="text" name="reference_company" class="transparent-input"value="<?php echo $row['reference_company']; ?>" readonly> </td>
						<td><input type="text" name="reference_position" class="transparent-input" value="<?php echo $row['reference_position']; ?>" readonly></td>
						<td><input type="text" name="reference_relationship" class="transparent-input" value="<?php echo $row['reference_relationship']; ?>"readonly></td>
					</tr>
					<tr>
						<td><input type="text" name="Name_reference1" class="transparent-input" value="<?php echo $row['Name_reference1']; ?>" readonly></td>
						<td><input type="text" name="contact_NO_reference1" pattern="[0-9]*" maxlength="11" class="transparent-input" value="<?php echo $row['contact_NO_reference1']; ?>" readonly></td>
						<td><input type="text" name="reference_company1" class="transparent-input" value="<?php echo $row['reference_company1']; ?>" readonly> </td>
						<td><input type="text" name="reference_position1" class="transparent-input"value="<?php echo $row['reference_position1']; ?>" readonly></td>
						<td><input type="text" name="reference_relationship1" class="transparent-input" value="<?php echo $row['reference_relationship1']; ?>"readonly></td>
					</tr>
				</tbody>
			</table>
			<br><br>

			<!-- PERSON TO BE NOTIFIED IN CASE OF EMERGENCY -->
			<table class="my-table">
				<caption><strong>PERSON TO BE NOTIFIED IN CASE OF EMERGENCY</strong></caption>
				<thead>
					<tr>
						<th class="name" style="background-color: #FFC000;">Name</th>
						<th class="contact-no" style="background-color: #FFC000;">Contact No.</th>
						<th class="address" style="background-color: #FFC000;">Address</th>
						<th class="relationship" style="background-color: #FFC000;">Relationship</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><input type="text" name="Name_emergency" class="transparent-input" value="<?php echo $row['Name_emergency']; ?>"readonly></td>
						<td><input type="text" name="contact_NO_emergency" pattern="[0-9]*" maxlength="11" class="transparent-input" value="<?php echo $row['contact_NO_emergency']; ?>"readonly></td>
						<td><input type="text" name="address_emergency" class="transparent-input" value="<?php echo $row['address_emergency']; ?>"readonly></td>
						<td><input type="text" name="relationship_emergency" class="transparent-input" value="<?php echo $row['relationship_emergency']; ?>"readonly></td>
					</tr>
				</tbody>
			</table>
			<br><br>
			
			<!-- CERTIFICATION -->
			<div class="certification-wrapper">
				<p class="certification-text" style="text-align: center;">"I hereby certify that all the above statements are true and correct. If any information relevant to or causing my employment with SCCI is later found to be false or incorrect, I may be subject to immediate dismissal, if then employed in any capacity."</p>
			</div>
			<div class="certification-card" style="background-color: #FFC000;">
			<table>
				<tr>
					<td><strong>Printed Name:</strong></td>
					<td><input type="text" name="e_signature_name" value="<?php echo $row['e_signature_name']; ?>" readonly></td>
				</tr>
				<div style="text-align: center;"> 
				<?php
				if (!empty($row['esig_name'])) {
					echo '<img src="data:image/jpeg;base64,'.base64_encode($row['esig_name']).'" alt="ID Picture" style="width: 30%; height: 30%; object-fit: contain;">';
				} else {
					echo '<img src="#" alt="ID Picture" width="50" height="50">';
				}
        
				?>
				  </div>
				<tr>
					<td><strong>Date:</strong></td>
					<td><input type="date" name="name_esignature" value="<?php echo $row['name_esignature']; ?>" readonly ></td>
				</tr>
			</table>
			</div>
			<br>

			</table>
			</div>	
            <br>

			<div style="text-align: center;">   
            <button onclick="window.print()">Print</button> 
             

            

            <input type="submit" name="download_excel" value="Download as Excel">
  
	<!-- FOOTER -->
	<div style="text-align: center; background-color: #FFC000; padding: 10px; font-size: 14px; margin-top: 10px; display: inline-block; width: 100%;"> © 2023 Scheirman Construction Consolidated Inc.</div>

 
			</div>
			</div>

</form>


<?php

/*
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;


// Assuming you have retrieved the user's selection and stored it in the $selectedId variable
$selectedId = $_POST['id']; // Assuming you're using POST method to submit the form

// Fetch the data from the database based on the selected ID
// Adjust this part based on your database connection and query method
$databaseData = fetchDataFromDatabase($id);

// Load the template Excel file
$templateFilePath = 'path/to/sample_template.xlsx';
$spreadsheet = IOFactory::load($templateFilePath);

// Get the active sheet in the spreadsheet (usually the first sheet)
$sheet = $spreadsheet->getActiveSheet();

    // Insert a value into a specific cell
    $sheet->setCellValue('C7', 'n_application');
  
         $sheet->setCellValue('B11:C11', 'referred_by');
          $sheet->setCellValue('F14:G14', 'apply.choice1');
           $sheet->setCellValue('I14:J14', 'apply.choice2');
            $sheet->setCellValue('A21:A22', 'surName');
             $sheet->setCellValue('C21:D22', 'given_name');
              $sheet->setCellValue('E21:F22', 'middle_name');
               $sheet->setCellValue('G21:I22', 'middle_initial');
                $sheet->setCellValue('J21:L22', 'nickName');
                 $sheet->setCellValue('B23:F24', 'present_address');
                  $sheet->setCellValue('H23:L24', 'Contact_NO');
                   $sheet->setCellValue('B25:F26', 'permanent_address');
                    $sheet->setCellValue('H25:L26', 'Contact_NO1');
                     
                      $sheet->setCellValue('C29:D30', 'birth_place');
                       $sheet->setCellValue('E29:F30', 'civil_status');
                        $sheet->setCellValue('J29:L30', 'religion');
                         $sheet->setCellValue('A32:B33', 'sss_NO');
                          $sheet->setCellValue('C32:D33', 'pag_ibig_NO');
                           $sheet->setCellValue('E32:F33', 'philhealth_NO');
                            $sheet->setCellValue('G32:I33', 'tin');
                             $sheet->setCellValue('J23:L33', 'tax_status');
                             
                              $sheet->setCellValue('A40:B40', 'fam_name');
                               $sheet->setCellValue('C40:D40', 'fam_relationship');
                                $sheet->setCellValue('E40:F40', 'fam_age');
                                 $sheet->setCellValue('G40:H40', 'fam_birth_date');
                                  $sheet->setCellValue('I40:J40', 'fam_civil_status');
                                   $sheet->setCellValue('K40:L40', 'fam_occupation');
                                    $sheet->setCellValue('M40:N40', 'fam_employer_school');

                                     $sheet->setCellValue('A41:B41', 'fam_name1');
                                      $sheet->setCellValue('C41:D41', 'fam_relationship1');
                                       $sheet->setCellValue('E41:F41', 'fam_age1');
                                        $sheet->setCellValue('G41:H41', 'fam_birth_date1');
                                         $sheet->setCellValue('I41:J41', 'fam_civil_status1');
                                          $sheet->setCellValue('K41:L41', 'fam_occupation1');
                                           $sheet->setCellValue('M41:N41', 'fam_employer_school1');

                                            $sheet->setCellValue('A42:B42', 'fam_name2');
                                             $sheet->setCellValue('C42:D42', 'fam_relationship2');
                                              $sheet->setCellValue('E42:F42', 'fam_age2');
                                               $sheet->setCellValue('G42:H42', 'fam_birth_date2');
                                                $sheet->setCellValue('I42:J42', 'fam_civil_status2');
                                                 $sheet->setCellValue('K42:L42', 'fam_occupation2');
                                                  $sheet->setCellValue('M42:N42', 'fam_employer_school2');

                                                   $sheet->setCellValue('A43:B43', 'fam_name3');
                                                    $sheet->setCellValue('C43:D43', 'fam_relationship3');
                                                     $sheet->setCellValue('E43:F43', 'fam_age3');
                                                      $sheet->setCellValue('G43:H43', 'fam_birth_date3');
                                                       $sheet->setCellValue('I43:J43', 'fam_civil_status3');
                                                        $sheet->setCellValue('K43:L43', 'fam_occupation3');
                                                         $sheet->setCellValue('M43:N43', 'fam_employer_school3');

                                                          $sheet->setCellValue('A44:B44', 'fam_name4');
                                                           $sheet->setCellValue('C44:D44', 'fam_relationship4');
                                                            $sheet->setCellValue('E44:F44', 'fam_age4');
                                                             $sheet->setCellValue('G44:H44', 'fam_birth_date');
                                                              $sheet->setCellValue('I44:J44', 'fam_civil_status4');
                                                               $sheet->setCellValue('K44:L44', 'fam_occupation4');
                                                                $sheet->setCellValue('M44:N44', 'fam_employer_school4');

                                                                 $sheet->setCellValue('C51:E52', 'post_graduate_from');
                                                                  $sheet->setCellValue('F51:H52', 'post_graduate_to');
                                                                   $sheet->setCellValue('I51:K52', 'post_graduate_course');
                                                                    $sheet->setCellValue('L51:N42', 'post_graduate_school');

                                                                     $sheet->setCellValue('C53:E54', 'tertiary_from');
                                                                      $sheet->setCellValue('F53:H54', 'tertiary_to');
                                                                       $sheet->setCellValue('I53:K54', 'tertiary_course');
                                                                        $sheet->setCellValue('L53:N54', 'tertiary_school');

                                                                        $sheet->setCellValue('C55:E56', 'vocational_from');
                                                                          $sheet->setCellValue('F55:H56', 'vocational_to');
                                                                            $sheet->setCellValue('I55:K56', 'vocational_course');
                                                                              $sheet->setCellValue('L55:N56', 'vocational_School');

                                                                              $sheet->setCellValue('C57:E58', 'high_school_from');
                                                                                $sheet->setCellValue('F57:H58', 'high_school_to');
                                                                                  $sheet->setCellValue('I57:K58', 'high_school_course');
                                                                                    $sheet->setCellValue('L57:N58', 'high_school_school');

                                                                                    $sheet->setCellValue('A66:C68', 'work_company_name');
                                                                                      $sheet->setCellValue('D66:F68', 'work_contact_NO');
                                                                                        $sheet->setCellValue('G66:J68', 'work_complete_address');
                                                                                         

                                                                                            $sheet->setCellValue('A70:C72', 'work_lastJob_title');
                                                                                          $sheet->setCellValue('D70:F72', 'work_Superiors_name');
                                                                                        
                                                                                     $sheet->setCellValue('K70:N72', 'work_Reason_for_leaving');

                                                                                    $sheet->setCellValue('A75:C77', 'work_company_name');
                                                                                 $sheet->setCellValue('D75:F77', 'work_contact_NO');
                                                                              $sheet->setCellValue('G75:J77', 'work_complete_address');
                                                                           

                                                                        $sheet->setCellValue('A79:C81', 'work_lastJob_title');
                                                                      $sheet->setCellValue('D79:F81', 'work_Superiors_name');
                                                                    
                                                                $sheet->setCellValue('K79:N81', 'work_Reason_for_leaving');

                                                                $sheet->setCellValue('A88:C90', 'licensure.board_exam_type');
                                                              $sheet->setCellValue('D88:F90', ' licensure.date_of_exam');
                                                            $sheet->setCellValue('G88:J90', ' licensure.rating');
                                                          $sheet->setCellValue('K88:N90', 'licensure.license_NO');

                                                       
                                                      $sheet->setCellValue('A94:N96', 'checkbox.crime_text');
                                                    
                                                    
                                                
                                                
                                              $sheet->setCellValue('A101:N103', 'checkbox.health_condition_text');

                                            $sheet->setCellValue('A116:B117', 'Name_reference');
                                          $sheet->setCellValue('C116:E117', 'contact_NO_reference');
                                        $sheet->setCellValue('F116:H117', 'reference_company');
                                      $sheet->setCellValue('I116:K117', 'reference_position');
                                    $sheet->setCellValue('L116:N117', 'reference_relationship');

                                  $sheet->setCellValue('A118:B119', 'Name_reference1');
                                $sheet->setCellValue('C118:E119', 'contact_NO_reference1');
                              $sheet->setCellValue('F118:H119', 'reference_company1');
                            $sheet->setCellValue('I118:K119', 'reference_position1');
                          $sheet->setCellValue('L118:N119', 'reference_relationship1');

                        $sheet->setCellValue('A125:C126', 'Name_emergency');  
                       $sheet->setCellValue('D125:F126', 'contact_NO_emergency');                                                              
                     $sheet->setCellValue('G125:K126', 'address_emergency');
                   $sheet->setCellValue('L125:N126', 'relationship_emergency');   

   
// Set the appropriate headers for the Excel file download
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="sample_template.xlsx"');
header('Cache-Control: max-age=0');

// Create a new Xlsx Writer instance
$writer = new Xlsx($spreadsheet);

// Save the modified Excel file to the output stream
$writer->save('php://output');
*/


?>


	</thead> 	
</table>

		<div class="overlay"></div>
  <table>
    <!-- your personal information -->
  </table>
 
  <script>
    // show/hide overlay when the table is focused
    const table = document.querySelector('table');
    const overlay = document.querySelector('.overlay');
    
    table.addEventListener('focusin', () => {
      overlay.style.display = 'block';
    });
    
    table.addEventListener('focusout', () => {
      overlay.style.display = 'none';
    });
  </script>

<script>
    var img = document.getElementById('id-picture');
    img.onload = function() {
        var container = document.querySelector('.picture-container');
        var widthRatio = container.offsetWidth / img.width;
        var heightRatio = container.offsetHeight / img.height;
        var ratio = Math.min(widthRatio, heightRatio);
        img.style.width = img.width * ratio + 'px';
        img.style.height = img.height * ratio + 'px';
        container.style.height = img.height * ratio + 'px';
    };
</script>

	</body>
</html>
