<?php
require_once('connection.php');

if (!$conn) {
    echo "";
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Certificate</title>
    <link rel="icon" type="image/png" href="img/lg.png">
    <link rel="stylesheet" type="text/css" href="redirect.css">
</head>

<body>
    <div class="certificate">
        <h2>Certificate of Submission</h2>
        <p class="received">This is to certify that</p>
        <p>Your submission has been received:</p>
        <ul>
           </li>
        </ul>
        <p>This certificate is presented with appreciation for your submission.</p>
        <p>Authorized Signature</p>
    </div>
</body>
</html>